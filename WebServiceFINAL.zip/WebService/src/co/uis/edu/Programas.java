package co.uis.edu;
import java.io.Serializable;

public class Programas implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7164160373160748894L;
	
	private int codigo_asignatura;
	private String nombre;
	private int codigo_programa;
	private String grupo;
	private int pla_estudio;
	private int cupos_matriculados;
	private int cancelaciones;
	private int aprobados;
	private int no_aprobados;
	private int homologados;
	
	
	public String getGrupo() {
		return grupo;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	public int getCodigo_asignatura() {
		return codigo_asignatura;
	}
	public void setCodigo_asignatura(int codigo_asignatura) {
		this.codigo_asignatura = codigo_asignatura;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCodigo_programa() {
		return codigo_programa;
	}
	public void setCodigo_programa(int codigo_programa) {
		this.codigo_programa = codigo_programa;
	}
	public int getPla_estudio() {
		return pla_estudio;
	}
	public void setPla_estudio(int pla_estudio) {
		this.pla_estudio = pla_estudio;
	}
	public int getCupos_matriculados() {
		return cupos_matriculados;
	}
	public void setCupos_matriculados(int cupos_matriculados) {
		this.cupos_matriculados = cupos_matriculados;
	}
	public int getCancelaciones() {
		return cancelaciones;
	}
	public void setCancelaciones(int cancelaciones) {
		this.cancelaciones = cancelaciones;
	}
	public int getAprobados() {
		return aprobados;
	}
	public void setAprobados(int aprobados) {
		this.aprobados = aprobados;
	}
	public int getNo_aprobados() {
		return no_aprobados;
	}
	public void setNo_aprobados(int no_aprobados) {
		this.no_aprobados = no_aprobados;
	}
	public int getHomologados() {
		return homologados;
	}
	public void setHomologados(int homologados) {
		this.homologados = homologados;
	}
	
	

}
