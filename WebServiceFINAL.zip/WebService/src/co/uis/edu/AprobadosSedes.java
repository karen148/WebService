package co.uis.edu;
import java.io.Serializable;

public class AprobadosSedes implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3551138233905467126L;
	private String nombre;
	private int codigo;
	private int codigo_sede;
	private int grupos;
	private int matriculas;
	private int cancelaciones;
	private int aprobados;
	private int no_aprobados;
	private int homologados;
	private int asignaturas;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public int getCodigo_sede() {
		return codigo_sede;
	}
	public void setCodigo_sede(int codigo_sede) {
		this.codigo_sede = codigo_sede;
	}
	public int getGrupos() {
		return grupos;
	}
	public void setGrupos(int grupos) {
		this.grupos = grupos;
	}
	public int getMatriculas() {
		return matriculas;
	}
	public void setMatriculas(int matriculas) {
		this.matriculas = matriculas;
	}
	public int getCancelaciones() {
		return cancelaciones;
	}
	public void setCancelaciones(int cancelaciones) {
		this.cancelaciones = cancelaciones;
	}
	public int getAprobados() {
		return aprobados;
	}
	public void setAprobados(int aprobados) {
		this.aprobados = aprobados;
	}
	public int getNo_aprobados() {
		return no_aprobados;
	}
	public void setNo_aprobados(int no_aprobados) {
		this.no_aprobados = no_aprobados;
	}
	public int getHomologados() {
		return homologados;
	}
	public void setHomologados(int homologados) {
		this.homologados = homologados;
	}
	public int getAsignaturas() {
		return asignaturas;
	}
	public void setAsignaturas(int asignaturas) {
		this.asignaturas = asignaturas;
	}
	
	
}
