package co.uis.edu;
import java.io.Serializable;

public class CancelacionesSedes implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -642630463186244878L;
	private int programa_academico;
	private String nombre;
	private int codigo_sede;
	private int cancelaciones;
	
	
	public int getPrograma_academico() {
		return programa_academico;
	}
	public void setPrograma_academico(int programa_academico) {
		this.programa_academico = programa_academico;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCodigo_sede() {
		return codigo_sede;
	}
	public void setCodigo_sede(int codigo_sede) {
		this.codigo_sede = codigo_sede;
	}
	public int getCancelaciones() {
		return cancelaciones;
	}
	public void setCancelaciones(int cancelaciones) {
		this.cancelaciones = cancelaciones;
	}
	

}
