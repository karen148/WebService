package co.uis.edu;
import java.io.Serializable;

public class HisProgramas implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -677574228678986974L;
	private int programa_academico;
	private String nombre;
	private int estudiantes;
	private int segundados;
	private int entercerados;
	private int encuartados;
	
	public int getPrograma_academico() {
		return programa_academico;
	}
	public void setPrograma_academico(int programa_academico) {
		this.programa_academico = programa_academico;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEstudiantes() {
		return estudiantes;
	}
	public void setEstudiantes(int estudiantes) {
		this.estudiantes = estudiantes;
	}
	public int getSegundados() {
		return segundados;
	}
	public void setSegundados(int segundados) {
		this.segundados = segundados;
	}
	public int getEntercerados() {
		return entercerados;
	}
	public void setEntercerados(int entercerados) {
		this.entercerados = entercerados;
	}
	public int getEncuartados() {
		return encuartados;
	}
	public void setEncuartados(int encuartados) {
		this.encuartados = encuartados;
	}
	

}
