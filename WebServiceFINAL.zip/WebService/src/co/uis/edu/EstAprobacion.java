package co.uis.edu;
import java.io.Serializable;

public class EstAprobacion implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5892540795476737796L;
	
	private String programa;
	private String asignatura;
	private int codigo_est;
	private String nombres;
	private String notas;
	private int codigo_sede;
	private String direccion_reside;
	private String nombre_municipio;
	private String telefono_reside;
	private String direccion_electron;
	private int programa_academico;
	private int codigo_asignatura;
	
	
	public int getPrograma_academico() {
		return programa_academico;
	}
	public void setPrograma_academico(int programa_academico) {
		this.programa_academico = programa_academico;
	}
	public int getCodigo_asignatura() {
		return codigo_asignatura;
	}
	public void setCodigo_asignatura(int codigo_asignatura) {
		this.codigo_asignatura = codigo_asignatura;
	}
	public String getPrograma() {
		return programa;
	}
	public void setPrograma(String programa) {
		this.programa = programa;
	}
	public String getAsignatura() {
		return asignatura;
	}
	public void setAsignatura(String asignatura) {
		this.asignatura = asignatura;
	}
	public int getCodigo_est() {
		return codigo_est;
	}
	public void setCodigo_est(int codigo_est) {
		this.codigo_est = codigo_est;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	public String getNotas() {
		return notas;
	}
	public void setNotas(String notas) {
		this.notas = notas;
	}
	public int getCodigo_sede() {
		return codigo_sede;
	}
	public void setCodigo_sede(int codigo_sede) {
		this.codigo_sede = codigo_sede;
	}
	public String getDireccion_reside() {
		return direccion_reside;
	}
	public void setDireccion_reside(String direccion_reside) {
		this.direccion_reside = direccion_reside;
	}
	public String getNombre_municipio() {
		return nombre_municipio;
	}
	public void setNombre_municipio(String nombre_municipio) {
		this.nombre_municipio = nombre_municipio;
	}
	public String getTelefono_reside() {
		return telefono_reside;
	}
	public void setTelefono_reside(String telefono_reside) {
		this.telefono_reside = telefono_reside;
	}
	public String getDireccion_electron() {
		return direccion_electron;
	}
	public void setDireccion_electron(String direccion_electron) {
		this.direccion_electron = direccion_electron;
	}
	
	
}
