package co.uis.edu;
import java.io.Serializable;

public class HisSemestreSede implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7749675343701788941L;
	private int ano;
	private int periodo;
	private int codigo_sede;
	private int estudiantes;
	private int segundados;
	private int entercerados;
	private int encuartados;
	
	
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public int getPeriodo() {
		return periodo;
	}
	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}
	public int getCodigo_sede() {
		return codigo_sede;
	}
	public void setCodigo_sede(int codigo_sede) {
		this.codigo_sede = codigo_sede;
	}
	public int getEstudiantes() {
		return estudiantes;
	}
	public void setEstudiantes(int estudiantes) {
		this.estudiantes = estudiantes;
	}
	public int getSegundados() {
		return segundados;
	}
	public void setSegundados(int segundados) {
		this.segundados = segundados;
	}
	public int getEntercerados() {
		return entercerados;
	}
	public void setEntercerados(int entercerados) {
		this.entercerados = entercerados;
	}
	public int getEncuartados() {
		return encuartados;
	}
	public void setEncuartados(int encuartados) {
		this.encuartados = encuartados;
	}
	
}
