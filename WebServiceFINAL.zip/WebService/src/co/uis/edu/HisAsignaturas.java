package co.uis.edu;
import java.io.Serializable;

public class HisAsignaturas implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2770597661902946668L;
	private int programa_academico;
	private String programa;
	private int codigo_asignatura;
	private String asignatura;
	private int estudiantes;
	private int segundados;
	private int entercerados;
	private int encuartados;
	
	public int getPrograma_academico() {
		return programa_academico;
	}
	public void setPrograma_academico(int programa_academico) {
		this.programa_academico = programa_academico;
	}
	public String getPrograma() {
		return programa;
	}
	public void setPrograma(String programa) {
		this.programa = programa;
	}
	public int getCodigo_asignatura() {
		return codigo_asignatura;
	}
	public void setCodigo_asignatura(int codigo_asignatura) {
		this.codigo_asignatura = codigo_asignatura;
	}
	public String getAsignatura() {
		return asignatura;
	}
	public void setAsignatura(String asignatura) {
		this.asignatura = asignatura;
	}
	public int getEstudiantes() {
		return estudiantes;
	}
	public void setEstudiantes(int estudiantes) {
		this.estudiantes = estudiantes;
	}
	public int getSegundados() {
		return segundados;
	}
	public void setSegundados(int segundados) {
		this.segundados = segundados;
	}
	public int getEntercerados() {
		return entercerados;
	}
	public void setEntercerados(int entercerados) {
		this.entercerados = entercerados;
	}
	public int getEncuartados() {
		return encuartados;
	}
	public void setEncuartados(int encuartados) {
		this.encuartados = encuartados;
	}
	
}
