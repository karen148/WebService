package co.uis.edu;
import java.io.Serializable;

public class CondicionalidadUno implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2512345915951139202L;
	private String nombre;
	private int normal;
	private int condicional_primera;
	private int condicional_segunda;
	private int pfu;
	private int retiro_periodo;
	private int excluido;
	private int graduado;
	private int retiro_voluntario;
	private int normalf;
	private int condicional_primeraf;
	private int condicional_segundaf;
	private int pfuf;
	private int retiro_periodof;
	private int excluidof;
	private int graduadof;
	private int retiro_voluntariof;
	
	public int getRetiro_periodo() {
		return retiro_periodo;
	}
	public void setRetiro_periodo(int retiro_periodo) {
		this.retiro_periodo = retiro_periodo;
	}
	public int getExcluido() {
		return excluido;
	}
	public void setExcluido(int excluido) {
		this.excluido = excluido;
	}
	public int getGraduado() {
		return graduado;
	}
	public void setGraduado(int graduado) {
		this.graduado = graduado;
	}
	public int getRetiro_periodof() {
		return retiro_periodof;
	}
	public void setRetiro_periodof(int retiro_periodof) {
		this.retiro_periodof = retiro_periodof;
	}
	public int getExcluidof() {
		return excluidof;
	}
	public void setExcluidof(int excluidof) {
		this.excluidof = excluidof;
	}
	public int getGraduadof() {
		return graduadof;
	}
	public void setGraduadof(int graduadof) {
		this.graduadof = graduadof;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNormal() {
		return normal;
	}
	public void setNormal(int normal) {
		this.normal = normal;
	}
	public int getCondicional_primera() {
		return condicional_primera;
	}
	public void setCondicional_primera(int condicional_primera) {
		this.condicional_primera = condicional_primera;
	}
	public int getCondicional_segunda() {
		return condicional_segunda;
	}
	public void setCondicional_segunda(int condicional_segunda) {
		this.condicional_segunda = condicional_segunda;
	}
	public int getPfu() {
		return pfu;
	}
	public void setPfu(int pfu) {
		this.pfu = pfu;
	}
	public int getRetiro_voluntario() {
		return retiro_voluntario;
	}
	public void setRetiro_voluntario(int retiro_voluntario) {
		this.retiro_voluntario = retiro_voluntario;
	}
	public int getNormalf() {
		return normalf;
	}
	public void setNormalf(int normalf) {
		this.normalf = normalf;
	}
	public int getCondicional_primeraf() {
		return condicional_primeraf;
	}
	public void setCondicional_primeraf(int condicional_primeraf) {
		this.condicional_primeraf = condicional_primeraf;
	}
	public int getCondicional_segundaf() {
		return condicional_segundaf;
	}
	public void setCondicional_segundaf(int condicional_segundaf) {
		this.condicional_segundaf = condicional_segundaf;
	}
	public int getPfuf() {
		return pfuf;
	}
	public void setPfuf(int pfuf) {
		this.pfuf = pfuf;
	}
	public int getRetiro_voluntariof() {
		return retiro_voluntariof;
	}
	public void setRetiro_voluntariof(int retiro_voluntariof) {
		this.retiro_voluntariof = retiro_voluntariof;
	}
	
}
