package co.uis.edu;
import java.io.Serializable;

public class MotivosSedes implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3214865843983888588L;
	private String nombre;
	private int codigo_sede;
	private int causa;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCodigo_sede() {
		return codigo_sede;
	}
	public void setCodigo_sede(int codigo_sede) {
		this.codigo_sede = codigo_sede;
	}
	public int getCausa() {
		return causa;
	}
	public void setCausa(int causa) {
		this.causa = causa;
	}
	
	
}
