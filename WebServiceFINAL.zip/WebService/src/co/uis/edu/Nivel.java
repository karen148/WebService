package co.uis.edu;
import java.io.Serializable;

public class Nivel implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7780253323728564162L;
	private String nombre;
	private int normal;
	private int condicional_primera;
	private int condicional_segunda;
	private int pfu;
	private int retiro_voluntario;
	private int normal1;
	private int condicional_primera1;
	private int condicional_segunda1;
	private int pfu1;
	private int retiro_voluntario1;
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getNormal() {
		return normal;
	}
	public void setNormal(int normal) {
		this.normal = normal;
	}
	public int getCondicional_primera() {
		return condicional_primera;
	}
	public void setCondicional_primera(int condicional_primera) {
		this.condicional_primera = condicional_primera;
	}
	public int getCondicional_segunda() {
		return condicional_segunda;
	}
	public void setCondicional_segunda(int condicional_segunda) {
		this.condicional_segunda = condicional_segunda;
	}
	public int getPfu() {
		return pfu;
	}
	public void setPfu(int pfu) {
		this.pfu = pfu;
	}
	public int getRetiro_voluntario() {
		return retiro_voluntario;
	}
	public void setRetiro_voluntario(int retiro_voluntario) {
		this.retiro_voluntario = retiro_voluntario;
	}
	public int getNormal1() {
		return normal1;
	}
	public void setNormal1(int normal1) {
		this.normal1 = normal1;
	}
	public int getCondicional_primera1() {
		return condicional_primera1;
	}
	public void setCondicional_primera1(int condicional_primera1) {
		this.condicional_primera1 = condicional_primera1;
	}
	public int getCondicional_segunda1() {
		return condicional_segunda1;
	}
	public void setCondicional_segunda1(int condicional_segunda1) {
		this.condicional_segunda1 = condicional_segunda1;
	}
	public int getPfu1() {
		return pfu1;
	}
	public void setPfu1(int pfu1) {
		this.pfu1 = pfu1;
	}
	public int getRetiro_voluntario1() {
		return retiro_voluntario1;
	}
	public void setRetiro_voluntario1(int retiro_voluntario1) {
		this.retiro_voluntario1 = retiro_voluntario1;
	}
	
	
}
