package co.uis.edu;
import java.io.Serializable;

public class Cancelaciones implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6049125262096529954L;
	private int programa_academico;
	private String nombre;
	private int cancelaciones;
	
	
	public int getPrograma_academico() {
		return programa_academico;
	}
	public void setPrograma_academico(int programa_academico) {
		this.programa_academico = programa_academico;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCancelaciones() {
		return cancelaciones;
	}
	public void setCancelaciones(int cancelaciones) {
		this.cancelaciones = cancelaciones;
	}

}
