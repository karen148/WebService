package co.uis.edu;
import java.io.Serializable;

public class Semestre implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7145019629750959792L;
	
	private int anio;
	private int periodo;
	public int getAnio() {
		return anio;
	}
	public void setAnio(int anio) {
		this.anio = anio;
	}
	public int getPeriodo() {
		return periodo;
	}
	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}
	
}
