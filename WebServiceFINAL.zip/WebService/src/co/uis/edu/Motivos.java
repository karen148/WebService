package co.uis.edu;
import java.io.Serializable;

public class Motivos implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3803084505779096972L;
	private String nombre;
	private int causa;
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCausa() {
		return causa;
	}
	public void setCausa(int causa) {
		this.causa = causa;
	}
	

}
