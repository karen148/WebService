package co.uis.edu;
import java.io.Serializable;

public class AcademicoSedes implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1025280671441030055L;
	private int programa_academico;
	private String nombre;
	private int codigo_sede;
	private int menor;
	private int tresdos;
	private int cuatro;
	private int cuatrocinco;
	private int cinco;
	
	
	public int getPrograma_academico() {
		return programa_academico;
	}
	public void setPrograma_academico(int programa_academico) {
		this.programa_academico = programa_academico;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getCodigo_sede() {
		return codigo_sede;
	}
	public void setCodigo_sede(int codigo_sede) {
		this.codigo_sede = codigo_sede;
	}
	public int getMenor() {
		return menor;
	}
	public void setMenor(int menor) {
		this.menor = menor;
	}
	public int getTresdos() {
		return tresdos;
	}
	public void setTresdos(int tresdos) {
		this.tresdos = tresdos;
	}
	public int getCuatro() {
		return cuatro;
	}
	public void setCuatro(int cuatro) {
		this.cuatro = cuatro;
	}
	public int getCuatrocinco() {
		return cuatrocinco;
	}
	public void setCuatrocinco(int cuatrocinco) {
		this.cuatrocinco = cuatrocinco;
	}
	public int getCinco() {
		return cinco;
	}
	public void setCinco(int cinco) {
		this.cinco = cinco;
	}
	
}
