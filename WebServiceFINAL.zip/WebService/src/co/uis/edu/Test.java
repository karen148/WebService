package co.uis.edu;

import javax.jws.WebService;
import javax.sql.DataSource;
import javax.jws.WebMethod;
import java.sql.*;

import java.util.ArrayList;
import java.util.List;

import java.lang.StringBuilder;

/**
 * Esta clase realiza una conexi�n a la base de datos informix eisiweb la cual
 * permite realizar consultas por medio de m�todos, los cuales retorna la
 * informaci�n por medio de listas para alimentar el m�dulo balance acad�mico de
 * la plataforma Moodle-SEA.
 * 
 * @author: Karen V. Gonzalez Mogoll�n - Lizeth P. Parra Bastos
 * @version: 23/11/2020
 * @since: v1
 *
 */

@WebService
public class Test {

	// Campos de la clase
	private Connection conexion;

	/**
	 * En este metodo se encuentra la conexi�n a la base de datos de informix.
	 * 
	 */
	private void conectar() {
		try {
			DataSource ds = null;
			//java:/eisiwebDS java:jdbc/eisiwebDS
			ds = (DataSource) new javax.naming.InitialContext().lookup("java:/eisiwebDS");
			this.conexion = ds.getConnection();
			System.out.print(this.conexion);
		} catch (Exception e) {
		}
	}// Cierre del m�todo

	/**
	 * M�todo retorna el �ltimo semestre que tenga promedios ponderados de los
	 * estudiantes del IPRED
	 * 
	 * @param: semestre: es una lista del objeto Semestre
	 * @return: semestre [ano,periodo]
	 */
	@WebMethod
	public List<Semestre> getSemestre() {

		this.conectar();
		Statement stm = null;
		ResultSet fila = null;
		List<Semestre> semestre = new ArrayList<Semestre>();
		try {

			// En la consulta se utiliza la tabla
			// acinsed:insed001.datos_periodo_est

			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.ano, l.periodo ");
			sql.append(" from (select max(n.ano_academico) as ano ");
			sql.append(" from acinsed:insed001.datos_periodo_est n ");
			sql.append(" ) as p ");
			sql.append(" inner join (select nt.ano_academico, max(nt.periodo_acad) as periodo ");
			sql.append(" from acinsed:insed001.datos_periodo_est nt ");
			sql.append(" group by nt.ano_academico ");
			sql.append(" ) as l ");
			sql.append(" on l.ano_academico = p.ano ");

			stm = conexion.createStatement();
			fila = stm.executeQuery(sql.toString());

			while(fila.next()) {
				Semestre se = new Semestre();
				se.setAnio(fila.getInt("ano"));
				se.setPeriodo(fila.getInt("periodo"));
				semestre.add(se);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return semestre;
	}

	/**
	 * M�todo getCondiconalidadUno obtiene el resultado de la consulta, en la
	 * cual se muestra la cantidad de estudiantes de cada programa acad�mico del
	 * IPRED clasificado seg�n su g�nero y estado condicional
	 * 
	 * @param: can: es una lista del objeto CondicionalidadUno
	 * @return: can []: en la lista se va encontrar la siquiente informaci�n
	 * @return: nombre: (String) nombre del programa
	 * @return: normal: (int) cantidad de estudiantes del genero masculino que
	 *          est�n en condiconalidad normal
	 * @return: condicional_primera: (int) cantidad de estudiantes del genero
	 *          masculino que est�n en condicionalidad por primera vez
	 * @return: condicional_segunda: (int) cantidad de estudiantes del genero
	 *          masculino que est�n en condicionalidad por segunda vez
	 * @return: pfu: (int) cantidad de estudiantes del genero masculino que
	 *          quedaron en pfu,
	 * @return: retiro_periodo: (int) cantidad de estudiantes del genero
	 *          masculino que est�n en retiro definitivo > 3 periodos
	 * @return: excluido: (int) cantidad de estudiantes del genero masculino que
	 *          est�n excluidos por vencimiento de tiempo
	 * @return: graduado: (int) cantidad de estudiantes del genero masculino que
	 *          se graduaron
	 * @return: retiro_voluntario:(int) cantidad de estudiantes del genero
	 *          masculino que se retiraron voluntariamente
	 * @return: normalf: (int) cantidad de estudiantes del genero femenino que
	 *          est�n en condiconalidad normal
	 * @return: condicional_primeraf: (int) cantidad de estudiantes del genero
	 *          femenino que est�n en condicionalidad por primera vez
	 * @return: condicional_segundaf: (int) cantidad de estudiantes del genero
	 *          femenino que est�n en condicionalidad por segunda vez
	 * @return: pfuf: (int) cantidad de estudiantes del genero femenino que
	 *          quedaron en pfu,
	 * @return: retiro_periodof: (int) cantidad de estudiantes del genero
	 *          femenino que est�n en retiro definitivo > 3 periodos
	 * @return: excluido,graduadof: (int) cantidad de estudiantes del genero
	 *          femenino que est�n excluidos por vencimiento de tiempo
	 * @return: retiro_voluntariof:(int) cantidad de estudiantes del genero
	 *          femenino que se retiraron voluntariamente
	 * @return: graduadof: (int) cantidad de estudiantes del genero femenino
	 *          que se graduaron
	 */
	@WebMethod
	public List<CondicionalidadUno> getCondicionalidadUno(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<CondicionalidadUno> can = new ArrayList<CondicionalidadUno>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" select p.nombre_programa, ");
			sql.append(" count(case when l.condicionalidad in (0,10) and dp.genero = 'M' then 1 end) as normal, ");
			sql.append(
					" count(case when l.condicionalidad in (1,9,6,18) and dp.genero = 'M' then 1 end) as condicional_primer, ");
			sql.append(
					" count(case when l.condicionalidad = 2 and dp.genero = 'M' then 1 end) as condicional_segunda, ");
			sql.append(
					" count(case when l.condicionalidad in (3,8,13,14,16,17) and dp.genero = 'M' then 1 end) as pfu, ");
			sql.append(" count(case when l.condicionalidad = 15 and dp.genero = 'M' then 1 end) as retiro_periodo, ");
			sql.append(" count(case when l.condicionalidad = 12 and dp.genero = 'M' then 1 end) as excluido, ");
			sql.append(" count(case when l.condicionalidad = 7 and dp.genero = 'M' then 1 end) as graduado, ");
			sql.append(
					" count(case when l.condicionalidad in (4,5) and dp.genero = 'M' then 1 end) as retiro_voluntario, ");
			sql.append(" count(case when l.condicionalidad in (0,10) and dp.genero = 'F' then 1 end) as normalf, ");
			sql.append(
					" count(case when l.condicionalidad in (1,9,6,18) and dp.genero = 'F' then 1 end) as condicional_primeraf, ");
			sql.append(
					" count(case when l.condicionalidad = 2 and dp.genero = 'F' then 1 end) as condicional_segundaf, ");
			sql.append(
					" count(case when l.condicionalidad in (3,8,13,14,16,17) and dp.genero = 'F' then 1 end) as pfuf, ");
			sql.append(" count(case when l.condicionalidad = 15 and dp.genero = 'F' then 1 end) as retiro_periodof, ");
			sql.append(" count(case when l.condicionalidad = 12 and dp.genero = 'F' then 1 end) as excluidof, ");
			sql.append(" count(case when l.condicionalidad = 7 and dp.genero = 'F' then 1 end) as graduadof, ");
			sql.append(
					" count(case when l.condicionalidad in (4,5) and dp.genero = 'F' then 1 end) as retiro_voluntariof ");
			sql.append(" from acinsed:insed001.datos_personal_est dp ");
			sql.append(" inner join (select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad ");
			sql.append(" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:cancelaciones_peri ca ");
			sql.append(" on pg.codigo_est = ca.codigo_est  ");
			sql.append(" and pg.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad ");
			sql.append(" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:matriculas ma ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select p.codigo_est, ");
			sql.append(" p.programa_academico, ");
			sql.append(" p.condicionalidad ");
			sql.append(" from (select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede, ");
			sql.append(" pg.ano_ing_sede || pg.periodo_ing_sede as semestre ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as p ");
			sql.append(" where p.semestre <> ?::varchar(5) || ?::varchar(2) ");
			sql.append(" union ");
			sql.append(" select ca.codigo_est, ");
			sql.append(" ca.programa_academico, ");
			sql.append(" 4 as condicionalidad ");
			sql.append(" from acinsed:cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad <> 4 ");
			sql.append(" ) as l ");
			sql.append(" on l.codigo_est = dp.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic p ");
			sql.append(" on l.programa_academico = p.programa_academico ");
			sql.append(" where l.programa_academico <> 17 and  ");
			sql.append(" l.programa_academico <> 84 ");
			sql.append(" group by p.nombre_programa ");
			sql.append(" order by p.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			System.out.print(stm);
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				CondicionalidadUno co = new CondicionalidadUno();
				co.setNombre(fila.getString("nombre_programa"));
				co.setNormal(fila.getInt("normal"));
				co.setNormalf(fila.getInt("normalf"));
				co.setCondicional_primera(fila.getInt("condicional_primer"));
				co.setCondicional_primeraf(fila.getInt("condicional_primeraf"));
				co.setCondicional_segunda(fila.getInt("condicional_segunda"));
				co.setCondicional_segundaf(fila.getInt("condicional_segundaf"));
				co.setPfu(fila.getInt("pfu"));
				co.setPfuf(fila.getInt("pfuf"));
				co.setRetiro_periodo(fila.getInt("retiro_periodo"));
				co.setRetiro_periodof(fila.getInt("retiro_periodof"));
				co.setExcluido(fila.getInt("excluido"));
				co.setExcluidof(fila.getInt("excluidof"));
				co.setGraduado(fila.getInt("graduado"));
				co.setGraduadof(fila.getInt("graduadof"));
				co.setRetiro_voluntario(fila.getInt("retiro_voluntario"));
				co.setRetiro_voluntariof(fila.getInt("retiro_voluntariof"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* CONDICIONALIDAD POR GENERO DEL SEMESTRE ACTUAL POR SEDES */
	@WebMethod
	public List<CondicionalidadSedes> getCondicionalidaSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 1;
		List<CondicionalidadSedes> can = new ArrayList<CondicionalidadSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" select p.nombre_programa,l.codigo_sede, ");
			sql.append(" count(case when l.condicionalidad in (0,10) and dp.genero = 'M' then 1 end) as normal, ");
			sql.append(
					" count(case when l.condicionalidad in (1,9,6,18) and dp.genero = 'M' then 1 end) as condicional_primer, ");
			sql.append(
					" count(case when l.condicionalidad = 2 and dp.genero = 'M' then 1 end) as condicional_segunda, ");
			sql.append(
					" count(case when l.condicionalidad in (3,8,13,14,16,17) and dp.genero = 'M' then 1 end) as pfu, ");
			sql.append(" count(case when l.condicionalidad = 15 and dp.genero = 'M' then 1 end) as retiro_periodo, ");
			sql.append(" count(case when l.condicionalidad = 12 and dp.genero = 'M' then 1 end) as excluido, ");
			sql.append(" count(case when l.condicionalidad = 7 and dp.genero = 'M' then 1 end) as graduado, ");
			sql.append(
					" count(case when l.condicionalidad in (4,5) and dp.genero = 'M' then 1 end) as retiro_voluntario, ");
			sql.append(" count(case when l.condicionalidad in (0,10) and dp.genero = 'F' then 1 end) as normalf, ");
			sql.append(
					" count(case when l.condicionalidad in (1,9,6,18) and dp.genero = 'F' then 1 end) as condicional_primeraf, ");
			sql.append(
					" count(case when l.condicionalidad = 2 and dp.genero = 'F' then 1 end) as condicional_segundaf, ");
			sql.append(
					" count(case when l.condicionalidad in (3,8,13,14,16,17) and dp.genero = 'F' then 1 end) as pfuf, ");
			sql.append(" count(case when l.condicionalidad = 15 and dp.genero = 'F' then 1 end) as retiro_periodof, ");
			sql.append(" count(case when l.condicionalidad = 12 and dp.genero = 'F' then 1 end) as excluidof, ");
			sql.append(" count(case when l.condicionalidad = 7 and dp.genero = 'F' then 1 end) as graduadof, ");
			sql.append(
					" count(case when l.condicionalidad in (4,5) and dp.genero = 'F' then 1 end) as retiro_voluntariof ");
			sql.append(" from acinsed:insed001.datos_personal_est dp ");
			sql.append(" inner join (select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and  pg.periodo_ing_sede = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:cancelaciones_peri ca ");
			sql.append(" on pg.codigo_est = ca.codigo_est  ");
			sql.append(" and pg.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:matriculas ma ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select p.codigo_est, ");
			sql.append(" p.programa_academico, ");
			sql.append(" p.condicionalidad, ");
			sql.append(" p.codigo_sede ");
			sql.append(" from (select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede, ");
			sql.append(" pg.ano_ing_sede || pg.periodo_ing_sede as semestre ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as p ");
			sql.append(" where p.semestre <> ?::varchar(5) || ?::varchar(2) ");
			sql.append(" union ");
			sql.append(" select ca.codigo_est, ");
			sql.append(" ca.programa_academico, ");
			sql.append(" 4 as condicionalidad, ");
			sql.append(" p.codigo_sede ");
			sql.append(" from acinsed:cancelaciones_peri ca ");
			sql.append(" full outer join acinsed:programas_acad_est p ");
			sql.append(" on p.codigo_est = ca.codigo_est ");
			sql.append(" and p.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and p.ano_condicion between ? and ? ");
			sql.append(" union ");
			sql.append(" select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad <> 4 ");
			sql.append(" ) as l ");
			sql.append(" on l.codigo_est = dp.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic p ");
			sql.append(" on l.programa_academico = p.programa_academico ");
			sql.append(" where l.programa_academico <> 17 and  ");
			sql.append(" l.programa_academico <> 84 ");
			sql.append(" group by p.nombre_programa,l.codigo_sede ");
			sql.append(" order by p.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			System.out.print(stm);
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, ann);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				CondicionalidadSedes co = new CondicionalidadSedes();
				co.setNombre(fila.getString("nombre_programa"));
				co.setcodigo_sede(fila.getInt("codigo_sede"));
				co.setNormal(fila.getInt("normal"));
				co.setNormalf(fila.getInt("normalf"));
				co.setCondicional_primera(fila.getInt("condicional_primer"));
				co.setCondicional_primeraf(fila.getInt("condicional_primeraf"));
				co.setCondicional_segunda(fila.getInt("condicional_segunda"));
				co.setCondicional_segundaf(fila.getInt("condicional_segundaf"));
				co.setPfu(fila.getInt("pfu"));
				co.setPfuf(fila.getInt("pfuf"));
				co.setRetiro_periodo(fila.getInt("retiro_periodo"));
				co.setRetiro_periodof(fila.getInt("retiro_periodof"));
				co.setExcluido(fila.getInt("excluido"));
				co.setExcluidof(fila.getInt("excluidof"));
				co.setGraduado(fila.getInt("graduado"));
				co.setGraduadof(fila.getInt("graduadof"));
				co.setRetiro_voluntario(fila.getInt("retiro_voluntario"));
				co.setRetiro_voluntariof(fila.getInt("retiro_voluntariof"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* CONDICIONALIDAD POR GENERO HISTORIAL */
	@WebMethod
	public List<CondicionalidadUno> getCondicionalidadHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<CondicionalidadUno> can = new ArrayList<CondicionalidadUno>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" select p.nombre_programa, ");
			sql.append(
					" count(case when l.condicionalidad in (0,10) and dp.genero = 'M' then 1 end) - count(case when l.condicionalidad = 21 and dp.genero = 'M' then 1 end) as normal, ");
			sql.append(
					" count(case when l.condicionalidad in (1,9,6,18) and dp.genero = 'M' then 1 end) as condicional_primer, ");
			sql.append(
					" count(case when l.condicionalidad = 2 and dp.genero = 'M' then 1 end) as condicional_segunda, ");
			sql.append(
					" count(case when l.condicionalidad in (3,8,13,14,16,17) and dp.genero = 'M' then 1 end) as pfu, ");
			sql.append(" count(case when l.condicionalidad = 15 and dp.genero = 'M' then 1 end) as retiro_periodo, ");
			sql.append(" count(case when l.condicionalidad = 12 and dp.genero = 'M' then 1 end) as excluido, ");
			sql.append(" count(case when l.condicionalidad = 7 and dp.genero = 'M' then 1 end) as graduado, ");
			sql.append(
					" count(case when l.condicionalidad in (4,5) and dp.genero = 'M' then 1 end) as retiro_voluntario, ");
			sql.append(
					" count(case when l.condicionalidad in (0,10) and dp.genero = 'F' then 1 end) - count(case when l.condicionalidad = 21 and dp.genero = 'F' then 1 end) as normalf, ");
			sql.append(
					" count(case when l.condicionalidad in (1,9,6,18) and dp.genero = 'F' then 1 end) as condicional_primeraf, ");
			sql.append(
					" count(case when l.condicionalidad = 2 and dp.genero = 'F' then 1 end) as condicional_segundaf, ");
			sql.append(
					" count(case when l.condicionalidad in (3,8,13,14,16,17) and dp.genero = 'F' then 1 end) as pfuf, ");
			sql.append(" count(case when l.condicionalidad = 15 and dp.genero = 'F' then 1 end) as retiro_periodof, ");
			sql.append(" count(case when l.condicionalidad = 12 and dp.genero = 'F' then 1 end) as excluidof, ");
			sql.append(" count(case when l.condicionalidad = 7 and dp.genero = 'F' then 1 end) as graduadof, ");
			sql.append(
					" count(case when l.condicionalidad in (4,5) and dp.genero = 'F' then 1 end) as retiro_voluntariof ");
			sql.append(" from (select distinct dt.codigo_est, m.programa_academico, dt.condicionalidad ");
			sql.append(" from acinsed:insed001.datos_periodo_est dt ");
			sql.append(" full outer join (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric,");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico,");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" ) as m ");
			sql.append(" on m.codigo_est = dt.codigo_est ");
			sql.append(" and m.programa_academico = dt.programa_academico ");
			sql.append(" and m.ano_matric = dt.ano_academico ");
			sql.append(" and m.periodo_matric = dt.periodo_acad ");
			sql.append(" where dt.ano_academico = ? ");
			sql.append(" and dt.periodo_acad = ? ");
			sql.append(" and m.programa_academico is not null ");
			sql.append(" and dt.condicionalidad <> 3 ");
			sql.append(" union ");
			sql.append(" select pc.codigo_est, pc.programa_academico, pc.condicionalidad ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (3,5,8,12,7,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad ");
			sql.append(" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_ing_sede = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:cancelaciones_peri ca ");
			sql.append(" on pg.codigo_est = ca.codigo_est  ");
			sql.append(" and pg.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad ");
			sql.append(" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:matriculas ma ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select p.codigo_est, ");
			sql.append(" p.programa_academico, ");
			sql.append(" p.condicionalidad ");
			sql.append(" from (select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede, ");
			sql.append(" pg.ano_ing_sede || pg.periodo_ing_sede as semestre ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as p ");
			sql.append(" where p.semestre <> ?::varchar(5) || ?::varchar(2) ");
			sql.append(" union ");
			sql.append(" select ca.codigo_est, ");
			sql.append(" ca.programa_academico, ");
			sql.append(" 4 as condicionalidad ");
			sql.append(" from acinsed:cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" case when pg.condicionalidad = 7 then 21 end as condicionalidad ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" and pg.ano_condicion = ma.ano_matric ");
			sql.append(" and pg.periodo_condicion = ma.periodo_matric ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.condicionalidad = 7 ");
			sql.append(" ) as l  ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = l.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic p ");
			sql.append(" on l.programa_academico = p.programa_academico ");
			sql.append(" where l.programa_academico <> 17 and  ");
			sql.append(" l.programa_academico <> 84 ");
			sql.append(" group by p.nombre_programa ");
			sql.append(" order by p.nombre_programa; ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			stm.setInt(21, anio);
			stm.setInt(22, periodo);
			stm.setInt(23, anio);
			stm.setInt(24, periodo);
			stm.setInt(25, anio);
			stm.setInt(26, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				CondicionalidadUno co = new CondicionalidadUno();
				co.setNombre(fila.getString("nombre_programa"));
				co.setNormal(fila.getInt("normal"));
				co.setNormalf(fila.getInt("normalf"));
				co.setCondicional_primera(fila.getInt("condicional_primer"));
				co.setCondicional_primeraf(fila.getInt("condicional_primeraf"));
				co.setCondicional_segunda(fila.getInt("condicional_segunda"));
				co.setCondicional_segundaf(fila.getInt("condicional_segundaf"));
				co.setPfu(fila.getInt("pfu"));
				co.setPfuf(fila.getInt("pfuf"));
				co.setRetiro_periodo(fila.getInt("retiro_periodo"));
				co.setRetiro_periodof(fila.getInt("retiro_periodof"));
				co.setExcluido(fila.getInt("excluido"));
				co.setExcluidof(fila.getInt("excluidof"));
				co.setGraduado(fila.getInt("graduado"));
				co.setGraduadof(fila.getInt("graduadof"));
				co.setRetiro_voluntario(fila.getInt("retiro_voluntario"));
				co.setRetiro_voluntariof(fila.getInt("retiro_voluntariof"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* CONDICIONALIDAD POR GENERO HISTORIAL SEDES */
	@WebMethod
	public List<CondicionalidadSedes> getCondicionalidadHisSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 1;
		List<CondicionalidadSedes> can = new ArrayList<CondicionalidadSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" select p.nombre_programa, l.codigo_sede,");
			sql.append(
					" abs(count(case when l.condicionalidad in (0,10) and dp.genero = 'M' then 1 end) - count(case when l.condicionalidad = 7 and dp.genero = 'M' then 1 end)) as normal, ");
			sql.append(
					" count(case when l.condicionalidad in (1,9,6,18) and dp.genero = 'M' then 1 end) as condicional_primer, ");
			sql.append(
					" count(case when l.condicionalidad = 2 and dp.genero = 'M' then 1 end) as condicional_segunda, ");
			sql.append(
					" count(case when l.condicionalidad in (3,8,13,14,16,17) and dp.genero = 'M' then 1 end) as pfu, ");
			sql.append(" count(case when l.condicionalidad = 15 and dp.genero = 'M' then 1 end) as retiro_periodo, ");
			sql.append(" count(case when l.condicionalidad = 12 and dp.genero = 'M' then 1 end) as excluido, ");
			sql.append(" count(case when l.condicionalidad = 7 and dp.genero = 'M' then 1 end) as graduado, ");
			sql.append(
					" count(case when l.condicionalidad in (4,5) and dp.genero = 'M' then 1 end) as retiro_voluntario, ");
			sql.append(
					" abs(count(case when l.condicionalidad in (0,10) and dp.genero = 'F' then 1 end) - count(case when l.condicionalidad = 7 and dp.genero = 'F' then 1 end)) as normalf, ");
			sql.append(
					" count(case when l.condicionalidad in (1,9,6,18) and dp.genero = 'F' then 1 end) as condicional_primeraf, ");
			sql.append(
					" count(case when l.condicionalidad = 2 and dp.genero = 'F' then 1 end) as condicional_segundaf, ");
			sql.append(
					" count(case when l.condicionalidad in (3,8,13,14,16,17) and dp.genero = 'F' then 1 end) as pfuf, ");
			sql.append(" count(case when l.condicionalidad = 15 and dp.genero = 'F' then 1 end) as retiro_periodof, ");
			sql.append(" count(case when l.condicionalidad = 12 and dp.genero = 'F' then 1 end) as excluidof, ");
			sql.append(" count(case when l.condicionalidad = 7 and dp.genero = 'F' then 1 end) as graduadof, ");
			sql.append(
					" count(case when l.condicionalidad in (4,5) and dp.genero = 'F' then 1 end) as retiro_voluntariof ");
			sql.append(
					" from (select distinct dt.codigo_est, m.programa_academico, dt.condicionalidad, pg.codigo_sede ");
			sql.append(" from acinsed:insed001.datos_periodo_est dt ");
			sql.append(" full outer join (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric,");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico,");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" ) as m ");
			sql.append(" on m.codigo_est = dt.codigo_est ");
			sql.append(" and m.programa_academico = dt.programa_academico ");
			sql.append(" and m.ano_matric = dt.ano_academico ");
			sql.append(" and m.periodo_matric = dt.periodo_acad ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = dt.codigo_est ");
			sql.append(" and pg.programa_academico = m.programa_academico ");
			sql.append(" where dt.ano_academico = ? ");
			sql.append(" and dt.periodo_acad = ? ");
			sql.append(" and m.programa_academico is not null ");
			sql.append(" and dt.condicionalidad <> 3 ");
			sql.append(" union ");
			sql.append(" select pc.codigo_est, pc.programa_academico, pc.condicionalidad, pc.codigo_sede ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (3,5,8,12,7,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_ing_sede = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:cancelaciones_peri ca ");
			sql.append(" on pg.codigo_est = ca.codigo_est  ");
			sql.append(" and pg.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:matriculas ma ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select p.codigo_est, ");
			sql.append(" p.programa_academico, ");
			sql.append(" p.condicionalidad, ");
			sql.append(" p.codigo_sede ");
			sql.append(" from (select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.codigo_sede, ");
			sql.append(" pg.ano_ing_sede || pg.periodo_ing_sede as semestre ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as p ");
			sql.append(" where p.semestre <> ?::varchar(5) || ?::varchar(2) ");
			sql.append(" union ");
			sql.append(" select ca.codigo_est, ");
			sql.append(" ca.programa_academico, ");
			sql.append(" 4 as condicionalidad, ");
			sql.append(" p.codigo_sede ");
			sql.append(" from acinsed:cancelaciones_peri ca ");
			sql.append(" full outer join acinsed:programas_acad_est p ");
			sql.append(" on p.codigo_est = ca.codigo_est ");
			sql.append(" and p.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and p.ano_condicion between ? and ? ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" case when pg.condicionalidad = 7 then 21 end as condicionalidad, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" and pg.ano_condicion = ma.ano_matric ");
			sql.append(" and pg.periodo_condicion = ma.periodo_matric ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.condicionalidad = 7 ");
			sql.append(" ) as l  ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = l.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic p ");
			sql.append(" on l.programa_academico = p.programa_academico ");
			sql.append(" where l.programa_academico <> 17 and  ");
			sql.append(" l.programa_academico <> 84 ");
			sql.append(" group by p.nombre_programa, l.codigo_sede ");
			sql.append(" order by p.nombre_programa; ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			stm.setInt(21, anio);
			stm.setInt(22, periodo);
			stm.setInt(23, anio);
			stm.setInt(24, periodo);
			stm.setInt(25, ann);
			stm.setInt(26, periodo);
			stm.setInt(27, anio);
			stm.setInt(28, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				CondicionalidadSedes co = new CondicionalidadSedes();
				co.setNombre(fila.getString("nombre_programa"));
				co.setcodigo_sede(fila.getInt("codigo_sede"));
				co.setNormal(fila.getInt("normal"));
				co.setNormalf(fila.getInt("normalf"));
				co.setCondicional_primera(fila.getInt("condicional_primer"));
				co.setCondicional_primeraf(fila.getInt("condicional_primeraf"));
				co.setCondicional_segunda(fila.getInt("condicional_segunda"));
				co.setCondicional_segundaf(fila.getInt("condicional_segundaf"));
				co.setPfu(fila.getInt("pfu"));
				co.setPfuf(fila.getInt("pfuf"));
				co.setRetiro_periodo(fila.getInt("retiro_periodo"));
				co.setRetiro_periodof(fila.getInt("retiro_periodof"));
				co.setExcluido(fila.getInt("excluido"));
				co.setExcluidof(fila.getInt("excluidof"));
				co.setGraduado(fila.getInt("graduado"));
				co.setGraduadof(fila.getInt("graduadof"));
				co.setRetiro_voluntario(fila.getInt("retiro_voluntario"));
				co.setRetiro_voluntariof(fila.getInt("retiro_voluntariof"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* NIVEL DEL SEMESTRE ACTUAL */
	@WebMethod
	public List<Nivel> getNivel(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 1;
		List<Nivel> can = new ArrayList<Nivel>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa, ");
			sql.append(" count(case when dp.condicionalidad in (0,10) then 1 end) as normal, ");
			sql.append(" count(case when dp.condicionalidad in (1,9,6,18) then 1 end) as condicional_primera, ");
			sql.append(" count(case when dp.condicionalidad = 2 then 1 end) as condicional_segunda, ");
			sql.append(" count(case when dp.condicionalidad in (3,8,13,14,16,17)  then 1 end) as pfu, ");
			sql.append(" count(case when dp.condicionalidad in (4,5) then 1 end) as retiro_voluntario, ");
			sql.append(
					" count(case when dp.condicionalidad in (0,10) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as normal1, ");
			sql.append(
					" count(case when dp.condicionalidad in (1,9,6,18) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as condicional_primera1, ");
			sql.append(
					" count(case when dp.condicionalidad in (3,8,13,14,16,17) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as pfu1, ");
			sql.append(
					" count(case when dp.condicionalidad in (4,5) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? then 1 end) as retiro_voluntario1 ");
			sql.append(" from ( select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede ");
			sql.append(
					" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad,pg.forma_ingreso,pg.ano_ing_sede,pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and  pg.periodo_ing_sede = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:cancelaciones_peri ca ");
			sql.append(" on pg.codigo_est = ca.codigo_est  ");
			sql.append(" and pg.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede ");
			sql.append(
					" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad,pg.forma_ingreso,pg.ano_ing_sede,pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:matriculas ma ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select p.codigo_est, ");
			sql.append(" p.programa_academico, ");
			sql.append(" p.condicionalidad, ");
			sql.append(" p.forma_ingreso, ");
			sql.append(" p.ano_ing_sede, ");
			sql.append(" p.periodo_ing_sede ");
			sql.append(" from (select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.ano_ing_sede || pg.periodo_ing_sede as semestre ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as p ");
			sql.append(" where p.semestre <> ?::varchar(5) || ?::varchar(2) ");
			sql.append(" union ");
			sql.append(" select ca.codigo_est, ");
			sql.append(" ca.programa_academico, ");
			sql.append(" 4 as condicionalidad, ");
			sql.append(" p.forma_ingreso, ");
			sql.append(" p.ano_ing_sede, ");
			sql.append(" p.periodo_ing_sede ");
			sql.append(" from acinsed:cancelaciones_peri ca ");
			sql.append(" full outer join acinsed:programas_acad_est p ");
			sql.append(" on p.codigo_est = ca.codigo_est ");
			sql.append(" and p.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and p.ano_condicion between ? and ? ");
			sql.append(" union ");
			sql.append(" select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad <> 4 ");
			sql.append(" ) as dp ");
			sql.append(" inner join academic:acpro001.programas_academic pa ");
			sql.append(" on pa.programa_academico = dp.programa_academico ");
			sql.append(" where dp.programa_academico <> 17 and  ");
			sql.append(" dp.programa_academico <> 84 ");
			sql.append(" group by pa.nombre_programa ");
			sql.append(" order by pa.nombre_programa ");
			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			stm.setInt(21, anio);
			stm.setInt(22, periodo);
			stm.setInt(23, anio);
			stm.setInt(24, periodo);
			stm.setInt(25, ann);
			stm.setInt(26, periodo);
			stm.setInt(27, anio);
			stm.setInt(28, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				Nivel co = new Nivel();
				co.setNombre(fila.getString("nombre_programa"));
				co.setNormal(fila.getInt("normal"));
				co.setCondicional_primera(fila.getInt("condicional_primera"));
				co.setCondicional_segunda(fila.getInt("condicional_segunda"));
				co.setPfu(fila.getInt("pfu"));
				co.setRetiro_voluntario(fila.getInt("retiro_voluntario"));
				co.setNormal1(fila.getInt("normal1"));
				co.setCondicional_primera1(fila.getInt("condicional_primera1"));
				co.setPfu1(fila.getInt("pfu1"));
				co.setRetiro_voluntario1(fila.getInt("retiro_voluntario1"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* NIVEL DEL SEMESTRE ACTUAL SEDES */
	@WebMethod
	public List<NivelSedes> getNivelSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 1;
		List<NivelSedes> can = new ArrayList<NivelSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa, dp.codigo_sede,");
			sql.append(" count(case when dp.condicionalidad in (0,10) then 1 end) as normal, ");
			sql.append(" count(case when dp.condicionalidad in (1,9,6,18) then 1 end) as condicional_primera, ");
			sql.append(" count(case when dp.condicionalidad = 2 then 1 end) as condicional_segunda, ");
			sql.append(" count(case when dp.condicionalidad in (3,8,13,14,16,17)  then 1 end) as pfu, ");
			sql.append(" count(case when dp.condicionalidad in (4,5) then 1 end) as retiro_voluntario, ");
			sql.append(
					" count(case when dp.condicionalidad in (0,10) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as normal1, ");
			sql.append(
					" count(case when dp.condicionalidad in (1,9,6,18) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as condicional_primera1, ");
			sql.append(
					" count(case when dp.condicionalidad in (3,8,13,14,16,17) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as pfu1, ");
			sql.append(
					" count(case when dp.condicionalidad in (4,5) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? then 1 end) as retiro_voluntario1 ");
			sql.append(" from ( select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede ");
			sql.append(
					" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad,pg.forma_ingreso,pg.ano_ing_sede,pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and  pg.periodo_ing_sede = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:cancelaciones_peri ca ");
			sql.append(" on pg.codigo_est = ca.codigo_est  ");
			sql.append(" and pg.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede ");
			sql.append(
					" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad,pg.forma_ingreso,pg.ano_ing_sede,pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:matriculas ma ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select p.codigo_est, ");
			sql.append(" p.programa_academico, ");
			sql.append(" p.condicionalidad, ");
			sql.append(" p.forma_ingreso, ");
			sql.append(" p.ano_ing_sede, ");
			sql.append(" p.periodo_ing_sede, ");
			sql.append(" p.codigo_sede ");
			sql.append(" from (select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede, ");
			sql.append(" pg.ano_ing_sede || pg.periodo_ing_sede as semestre ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as p ");
			sql.append(" where p.semestre <> ?::varchar(5) || ?::varchar(2) ");
			sql.append(" union ");
			sql.append(" select ca.codigo_est, ");
			sql.append(" ca.programa_academico, ");
			sql.append(" 4 as condicionalidad, ");
			sql.append(" p.forma_ingreso, ");
			sql.append(" p.ano_ing_sede, ");
			sql.append(" p.periodo_ing_sede, ");
			sql.append(" p.codigo_sede ");
			sql.append(" from acinsed:cancelaciones_peri ca ");
			sql.append(" full outer join acinsed:programas_acad_est p ");
			sql.append(" on p.codigo_est = ca.codigo_est ");
			sql.append(" and p.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and p.ano_condicion between ? and ? ");
			sql.append(" union ");
			sql.append(" select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad <> 4 ");
			sql.append(" ) as dp ");
			sql.append(" inner join academic:acpro001.programas_academic pa ");
			sql.append(" on pa.programa_academico = dp.programa_academico ");
			sql.append(" where dp.programa_academico <> 17 and  ");
			sql.append(" dp.programa_academico <> 84 ");
			sql.append(" group by pa.nombre_programa, dp.codigo_sede ");
			sql.append(" order by pa.nombre_programa ");
			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			stm.setInt(21, anio);
			stm.setInt(22, periodo);
			stm.setInt(23, anio);
			stm.setInt(24, periodo);
			stm.setInt(25, ann);
			stm.setInt(26, periodo);
			stm.setInt(27, anio);
			stm.setInt(28, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				NivelSedes co = new NivelSedes();
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setNormal(fila.getInt("normal"));
				co.setCondicional_primera(fila.getInt("condicional_primera"));
				co.setCondicional_segunda(fila.getInt("condicional_segunda"));
				co.setPfu(fila.getInt("pfu"));
				co.setRetiro_voluntario(fila.getInt("retiro_voluntario"));
				co.setNormal1(fila.getInt("normal1"));
				co.setCondicional_primera1(fila.getInt("condicional_primera1"));
				co.setPfu1(fila.getInt("pfu1"));
				co.setRetiro_voluntario1(fila.getInt("retiro_voluntario1"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* NIVEL HISTORIAL */
	@WebMethod
	public List<Nivel> getNivelHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 1;
		List<Nivel> can = new ArrayList<Nivel>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa, ");
			sql.append(
					" count(case when dp.condicionalidad in (0,10) then 1 end) -  count(case when dp.condicionalidad = 21 then 1 end) as normal, ");
			sql.append(" count(case when dp.condicionalidad in (1,9,6,18) then 1 end) as condicional_primera, ");
			sql.append(" count(case when dp.condicionalidad = 2 then 1 end) as condicional_segunda, ");
			sql.append(" count(case when dp.condicionalidad in (3,8,13,14,16,17)  then 1 end) as pfu, ");
			sql.append(" count(case when dp.condicionalidad in (4,5) then 1 end) as retiro_voluntario, ");
			sql.append(
					" count(case when dp.condicionalidad in (0,10) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as normal1, ");
			sql.append(
					" count(case when dp.condicionalidad in (1,9,6,18) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as condicional_primera1, ");
			sql.append(
					" count(case when dp.condicionalidad in (3,8,13,14,16,17) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as pfu1, ");
			sql.append(
					" count(case when dp.condicionalidad in (4,5) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? then 1 end) as retiro_voluntario1 ");
			sql.append(
					" from (select distinct dt.codigo_est, m.programa_academico, dt.condicionalidad, pg.forma_ingreso, pg.ano_ing_sede, pg.periodo_ing_sede ");
			sql.append(" from acinsed:insed001.datos_periodo_est dt ");
			sql.append(" full outer join (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" ) as m ");
			sql.append(" on m.codigo_est = dt.codigo_est ");
			sql.append(" and m.programa_academico = dt.programa_academico ");
			sql.append(" and m.ano_matric = dt.ano_academico ");
			sql.append(" and m.periodo_matric = dt.periodo_acad ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = dt.codigo_est ");
			sql.append(" and pg.programa_academico = m.programa_academico ");
			sql.append(" where dt.ano_academico = ? ");
			sql.append(" and dt.periodo_acad = ? ");
			sql.append(" and m.programa_academico is not null ");
			sql.append(" and dt.condicionalidad <> 3 ");
			sql.append(" union ");
			sql.append(
					" select pc.codigo_est, pc.programa_academico, pc.condicionalidad, pc.forma_ingreso, pc.ano_ing_sede, pc.periodo_ing_sede ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (3,5,8,4,12,7,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede ");
			sql.append(
					" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad,pg.forma_ingreso,pg.ano_ing_sede,pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_ing_sede = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:cancelaciones_peri ca ");
			sql.append(" on pg.codigo_est = ca.codigo_est  ");
			sql.append(" and pg.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede ");
			sql.append(
					" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad,pg.forma_ingreso,pg.ano_ing_sede,pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:matriculas ma ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select p.codigo_est, ");
			sql.append(" p.programa_academico, ");
			sql.append(" p.condicionalidad, ");
			sql.append(" p.forma_ingreso, ");
			sql.append(" p.ano_ing_sede, ");
			sql.append(" p.periodo_ing_sede ");
			sql.append(" from (select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.ano_ing_sede || pg.periodo_ing_sede as semestre ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as p ");
			sql.append(" where p.semestre <> ?::varchar(5) || ?::varchar(2) ");
			sql.append(" union ");
			sql.append(" select ca.codigo_est, ");
			sql.append(" ca.programa_academico, ");
			sql.append(" 4 as condicionalidad, ");
			sql.append(" p.forma_ingreso, ");
			sql.append(" p.ano_ing_sede, ");
			sql.append(" p.periodo_ing_sede ");
			sql.append(" from acinsed:cancelaciones_peri ca ");
			sql.append(" full outer join acinsed:programas_acad_est p ");
			sql.append(" on p.codigo_est = ca.codigo_est ");
			sql.append(" and p.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and p.ano_condicion between ? and ? ");
			sql.append(" union ");
			sql.append(" select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad <> 4 ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" case when pg.condicionalidad = 7 then 21 end as condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" and pg.ano_condicion = ma.ano_matric ");
			sql.append(" and pg.periodo_condicion = ma.periodo_matric ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.condicionalidad = 7 ");
			sql.append(" ) as dp ");
			sql.append(" inner join academic:acpro001.programas_academic pa ");
			sql.append(" on pa.programa_academico = dp.programa_academico ");
			sql.append(" where dp.programa_academico <> 17 and  ");
			sql.append(" dp.programa_academico <> 84 ");
			sql.append(" group by pa.nombre_programa ");
			sql.append(" order by pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			stm.setInt(21, anio);
			stm.setInt(22, periodo);
			stm.setInt(23, anio);
			stm.setInt(24, periodo);
			stm.setInt(25, anio);
			stm.setInt(26, periodo);
			stm.setInt(27, anio);
			stm.setInt(28, periodo);
			stm.setInt(29, anio);
			stm.setInt(30, periodo);
			stm.setInt(31, anio);
			stm.setInt(32, periodo);
			stm.setInt(33, ann);
			stm.setInt(34, periodo);
			stm.setInt(35, anio);
			stm.setInt(36, periodo);
			stm.setInt(37, anio);
			stm.setInt(38, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				Nivel co = new Nivel();
				co.setNombre(fila.getString("nombre_programa"));
				co.setNormal(fila.getInt("normal"));
				co.setCondicional_primera(fila.getInt("condicional_primera"));
				co.setCondicional_segunda(fila.getInt("condicional_segunda"));
				co.setPfu(fila.getInt("pfu"));
				co.setRetiro_voluntario(fila.getInt("retiro_voluntario"));
				co.setNormal1(fila.getInt("normal1"));
				co.setCondicional_primera1(fila.getInt("condicional_primera1"));
				co.setPfu1(fila.getInt("pfu1"));
				co.setRetiro_voluntario1(fila.getInt("retiro_voluntario1"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* NIVEL HISTORIAL SEDES */
	@WebMethod
	public List<NivelSedes> getNivelHisSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 1;
		List<NivelSedes> can = new ArrayList<NivelSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa,dp.codigo_sede, ");
			sql.append(
					" count(case when dp.condicionalidad in (0,10) then 1 end) -  count(case when dp.condicionalidad = 21 then 1 end) as normal, ");
			sql.append(" count(case when dp.condicionalidad in (1,9,6,18) then 1 end) as condicional_primera, ");
			sql.append(" count(case when dp.condicionalidad = 2 then 1 end) as condicional_segunda, ");
			sql.append(" count(case when dp.condicionalidad in (3,8,13,14,16,17)  then 1 end) as pfu, ");
			sql.append(" count(case when dp.condicionalidad in (4,5) then 1 end) as retiro_voluntario, ");
			sql.append(
					" count(case when dp.condicionalidad in (0,10) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as normal1, ");
			sql.append(
					" count(case when dp.condicionalidad in (1,9,6,18) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as condicional_primera1, ");
			sql.append(
					" count(case when dp.condicionalidad in (3,8,13,14,16,17) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? and dp.forma_ingreso = 2 then 1 end) as pfu1, ");
			sql.append(
					" count(case when dp.condicionalidad in (4,5) and dp.ano_ing_sede = ? and dp.periodo_ing_sede = ? then 1 end) as retiro_voluntario1 ");
			sql.append(
					" from (select distinct dt.codigo_est, m.programa_academico, dt.condicionalidad, pg.forma_ingreso, pg.ano_ing_sede, pg.periodo_ing_sede, pg.codigo_sede ");
			sql.append(" from acinsed:insed001.datos_periodo_est dt ");
			sql.append(" full outer join (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" ) as m ");
			sql.append(" on m.codigo_est = dt.codigo_est ");
			sql.append(" and m.programa_academico = dt.programa_academico ");
			sql.append(" and m.ano_matric = dt.ano_academico ");
			sql.append(" and m.periodo_matric = dt.periodo_acad ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = dt.codigo_est ");
			sql.append(" and pg.programa_academico = m.programa_academico ");
			sql.append(" where dt.ano_academico = ? ");
			sql.append(" and dt.periodo_acad = ? ");
			sql.append(" and m.programa_academico is not null ");
			sql.append(" and dt.condicionalidad <> 3 ");
			sql.append(" union ");
			sql.append(
					" select pc.codigo_est, pc.programa_academico, pc.condicionalidad,pc.forma_ingreso, pc.ano_ing_sede, pc.periodo_ing_sede, pc.codigo_sede ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (3,5,8,4,12,7,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede ");
			sql.append(
					" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad,pg.forma_ingreso,pg.ano_ing_sede,pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_ing_sede = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:cancelaciones_peri ca ");
			sql.append(" on pg.codigo_est = ca.codigo_est  ");
			sql.append(" and pg.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede ");
			sql.append(
					" from(select pg.codigo_est, pg.programa_academico,pg.codigo_sede,pg.condicionalidad,pg.forma_ingreso,pg.ano_ing_sede,pg.periodo_ing_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_ing_sede = ? ");
			sql.append(" and pg.periodo_ing_sede = ? ");
			sql.append(" and pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as pg ");
			sql.append(" full outer join acinsed:matriculas ma ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.codigo_est is not null ");
			sql.append(" union ");
			sql.append(" select p.codigo_est, ");
			sql.append(" p.programa_academico, ");
			sql.append(" p.condicionalidad, ");
			sql.append(" p.forma_ingreso, ");
			sql.append(" p.ano_ing_sede, ");
			sql.append(" p.periodo_ing_sede, ");
			sql.append(" p.codigo_sede ");
			sql.append(" from (select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede, ");
			sql.append(" pg.ano_ing_sede || pg.periodo_ing_sede as semestre ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad = 4 ");
			sql.append(" ) as p ");
			sql.append(" where p.semestre <> ?::varchar(5) || ?::varchar(2) ");
			sql.append(" union ");
			sql.append(" select ca.codigo_est, ");
			sql.append(" ca.programa_academico, ");
			sql.append(" 4 as condicionalidad, ");
			sql.append(" p.forma_ingreso, ");
			sql.append(" p.ano_ing_sede, ");
			sql.append(" p.periodo_ing_sede, ");
			sql.append(" p.codigo_sede ");
			sql.append(" from acinsed:cancelaciones_peri ca ");
			sql.append(" full outer join acinsed:programas_acad_est p ");
			sql.append(" on p.codigo_est = ca.codigo_est ");
			sql.append(" and p.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" and p.ano_condicion between ? and ? ");
			sql.append(" union ");
			sql.append(" select pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" pg.condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from acinsed:programas_acad_est pg ");
			sql.append(" where pg.ano_condicion = ? ");
			sql.append(" and pg.periodo_condicion = ? ");
			sql.append(" and pg.condicionalidad <> 4 ");
			sql.append(" union ");
			sql.append(" select distinct pg.codigo_est, ");
			sql.append(" pg.programa_academico, ");
			sql.append(" case when pg.condicionalidad = 7 then 21 end as condicionalidad, ");
			sql.append(" pg.forma_ingreso, ");
			sql.append(" pg.ano_ing_sede, ");
			sql.append(" pg.periodo_ing_sede, ");
			sql.append(" pg.codigo_sede ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = ma.codigo_est ");
			sql.append(" and pg.programa_academico = ma.programa_academico ");
			sql.append(" and pg.ano_condicion = ma.ano_matric ");
			sql.append(" and pg.periodo_condicion = ma.periodo_matric ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" and pg.condicionalidad = 7 ");
			sql.append(" ) as dp ");
			sql.append(" inner join academic:acpro001.programas_academic pa ");
			sql.append(" on pa.programa_academico = dp.programa_academico ");
			sql.append(" where dp.programa_academico <> 17 and  ");
			sql.append(" dp.programa_academico <> 84 ");
			sql.append(" group by pa.nombre_programa, dp.codigo_sede ");
			sql.append(" order by pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			stm.setInt(21, anio);
			stm.setInt(22, periodo);
			stm.setInt(23, anio);
			stm.setInt(24, periodo);
			stm.setInt(25, anio);
			stm.setInt(26, periodo);
			stm.setInt(27, anio);
			stm.setInt(28, periodo);
			stm.setInt(29, anio);
			stm.setInt(30, periodo);
			stm.setInt(31, anio);
			stm.setInt(32, periodo);
			stm.setInt(33, ann);
			stm.setInt(34, periodo);
			stm.setInt(35, anio);
			stm.setInt(36, periodo);
			stm.setInt(37, anio);
			stm.setInt(38, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				NivelSedes co = new NivelSedes();
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setNormal(fila.getInt("normal"));
				co.setCondicional_primera(fila.getInt("condicional_primera"));
				co.setCondicional_segunda(fila.getInt("condicional_segunda"));
				co.setPfu(fila.getInt("pfu"));
				co.setRetiro_voluntario(fila.getInt("retiro_voluntario"));
				co.setNormal1(fila.getInt("normal1"));
				co.setCondicional_primera1(fila.getInt("condicional_primera1"));
				co.setPfu1(fila.getInt("pfu1"));
				co.setRetiro_voluntario1(fila.getInt("retiro_voluntario1"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* APROBADO DEL SEMESTRE ACTUAL */
	@WebMethod
	public List<Aprobados> getAprobados(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<Aprobados> can = new ArrayList<Aprobados>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.nombre_programa, ");
			sql.append(" p.programa_academico, ");
			sql.append(" g.grupos, ");
			sql.append(" mtr.matriculas, ");
			sql.append(" can.cancelaciones, ");
			sql.append(" asig.aprobados, ");
			sql.append(" asig.no_aprobados, ");
			sql.append(" asig.homologados, ");
			sql.append(" count(ma.codigo_asignatura) as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan ma ");
			sql.append(" inner join academic:acpro001.programas_academic p ");
			sql.append(" on p.programa_academico = ma.programa_academico ");
			sql.append(" left join (select asig.programa_academico, count (gru.grupo) as grupos ");
			sql.append(" from acinsed:insed001.grupos_asignatura gru ");
			sql.append(" full outer join ( ");
			sql.append(" select  pro.programa_academico, ");
			sql.append(
					" case when pro.nivel_plan between '1' and '4' and pro.programa_academico = '87' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between '5' and '6' and pro.programa_academico = '8' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in ('7','8','9','10') and pro.programa_academico = '86' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '70' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '71' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '13' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '82' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '61' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '17' then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in ('87','8','86','70','71','13','82','61','17') ");
			sql.append(" ) as asig ");
			sql.append(" on asig.asignaturas = gru.codigo_asignatura ");
			sql.append(" where gru.ano = ? ");
			sql.append(" and gru.periodo = ? ");
			sql.append(" and gru.matriculados > 0 ");
			sql.append(" group by asig.programa_academico ");
			sql.append(" ) as g ");
			sql.append(" on ma.programa_academico = g.programa_academico ");
			sql.append(" left join (SELECT m.programa_academico,count(m.codigo_asignatura) as matriculas ");
			sql.append(" from acinsed:insed001.matriculas m ");
			sql.append(" where m.ano_matric = ? and ");
			sql.append(" m.periodo_matric = ? ");
			sql.append(" group by m.programa_academico ");
			sql.append(" ) as mtr ");
			sql.append(" on ma.programa_academico = mtr.programa_academico ");
			sql.append(" left join (SELECT ca.programa_academico, ");
			sql.append(" count(ca.codigo_est) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" where ca.ano_cancel = ? and ");
			sql.append(" ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico ");
			sql.append(" ) as can ");
			sql.append(" on ma.programa_academico = can.programa_academico ");
			sql.append(" left join (select np.programa_academico, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 3.0 and 5.0 then 1 end) + count(case when np.nota_c_def_asig = 'A' then 1 end) as aprobados, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 0.0 and 2.9 then 1 end) +  count(case when np.nota_c_def_asig = 'R' then 1 end) as no_aprobados, ");
			sql.append(" count(case when np.grupo = 'HOM' then 1 end) as homologados ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est as pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? and ");
			sql.append(" np.grupo <> 'HOM' ");
			sql.append(" group by np.programa_academico ");
			sql.append(" ) as asig ");
			sql.append(" on ma.programa_academico = asig.programa_academico ");
			sql.append(" where ma.plan_estudio = (select max(pro.plan_estudio) ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" where pro.programa_academico = p.programa_academico ");
			sql.append(" group by pro.programa_academico ");
			sql.append(" ) ");
			sql.append(" and g.grupos is not null ");
			sql.append(
					" group by p.nombre_programa,p.programa_academico,g.grupos,mtr.matriculas,can.cancelaciones,asig.aprobados,asig.no_aprobados,asig.homologados ");
			sql.append(" order by p.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);

			fila = stm.executeQuery();
			while (fila.next()) {
				Aprobados co = new Aprobados();
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo(fila.getInt("programa_academico"));
				co.setGrupos(fila.getInt("grupos"));
				co.setMatriculas(fila.getInt("matriculas"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				co.setAprobados(fila.getInt("aprobados"));
				co.setNo_aprobados(fila.getInt("no_aprobados"));
				co.setHomologados(fila.getInt("homologados"));
				co.setAsignaturas(fila.getInt("asignaturas"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* APROBADO DEL SEMESTRE ACTUAL SEDES */
	@WebMethod
	public List<AprobadosSedes> getAprobadosSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<AprobadosSedes> can = new ArrayList<AprobadosSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT distinct t.nombre_programa, ");
			sql.append(" t.programa_academico, ");
			sql.append(" pr.codigo_sede, ");
			sql.append(" t.asignaturas, ");
			sql.append(" case when gr.grupos is null then 0 ");
			sql.append(" else gr.grupos ");
			sql.append(" end as grupos, ");
			sql.append(" mc.matriculas, ");
			sql.append(" mc.cancelaciones, ");
			sql.append(" est.aprobados, ");
			sql.append(" est.no_aprobados, ");
			sql.append(" est.homologados ");
			sql.append(" from (select p.nombre_programa, ");
			sql.append(" p.programa_academico, ");
			sql.append(" count(ma.codigo_asignatura) as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan ma ");
			sql.append(" inner join academic:acpro001.programas_academic p ");
			sql.append(" on p.programa_academico = ma.programa_academico ");
			sql.append(" where ma.plan_estudio = (select max(pro.plan_estudio) ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" where pro.programa_academico = p.programa_academico ");
			sql.append(" group by pro.programa_academico ");
			sql.append(" ) ");
			sql.append(" group by p.nombre_programa,p.programa_academico ");
			sql.append(" ) as t ");
			sql.append(" left join acinsed:insed001.programas_acad_est pr ");
			sql.append(" on t.programa_academico = pr.programa_academico ");
			sql.append(" left join (select asig.programa_academico, count (gru.grupo) as grupos,gru.codigo_sede ");
			sql.append(" from acinsed:insed001.grupos_asignatura gru ");
			sql.append(" full outer join ( ");
			sql.append(" select  pro.programa_academico, ");
			sql.append(
					" case when pro.nivel_plan between '1' and '4' and pro.programa_academico = '87' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between '5' and '6' and pro.programa_academico = '8' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in ('7','8','9','10') and pro.programa_academico = '86' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '70' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '71' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '13' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '82' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '61' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '17' then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in ('87','8','86','70','71','13','82','61','17') ");
			sql.append(" ) as asig ");
			sql.append(" on asig.asignaturas = gru.codigo_asignatura ");
			sql.append(" where gru.ano = ? ");
			sql.append(" and gru.periodo = ? ");
			sql.append(" and gru.matriculados > 0 ");
			sql.append(" group by asig.programa_academico,gru.codigo_sede ");
			sql.append(" ) as gr ");
			sql.append(" on t.programa_academico = gr.programa_academico and ");
			sql.append(" pr.codigo_sede = gr.codigo_sede ");
			sql.append(" left join (SELECT y.programa_academico, ");
			sql.append(" y.matriculas, ");
			sql.append(" y.codigo_sede, ");
			sql.append(" CASE WHEN k.cancelaciones IS NULL THEN 0 ");
			sql.append(" ELSE k.cancelaciones ");
			sql.append(" END AS cancelaciones ");
			sql.append(" from (select ma.programa_academico, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" count(ma.codigo_asignatura) as matriculas ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ma.programa_academico and ");
			sql.append(" pro.codigo_est = ma.codigo_est ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pro.codigo_sede is not null ");
			sql.append(" group by ma.programa_academico, pro.codigo_sede ");
			sql.append(" ) as y ");
			sql.append(" full outer join(select  ca.programa_academico, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" count(ca.codigo_asignatura) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico and ");
			sql.append(" pro.codigo_est = ca.codigo_est ");
			sql.append(" where ca.ano_cancel = ? and ");
			sql.append(" ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico,pro.codigo_sede ");
			sql.append(" ) as k ");
			sql.append(" on k.programa_academico = y.programa_academico and ");
			sql.append(" k.codigo_sede = y.codigo_sede ");
			sql.append(" ) as mc ");
			sql.append(" on t.programa_academico = mc.programa_academico and ");
			sql.append(" pr.codigo_sede = mc.codigo_sede ");
			sql.append(" left join (select np.programa_academico, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 3.0 and 5.0 then 1 end) + count(case when np.nota_c_def_asig = 'A' then 1 end) as aprobados, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 0.0 and 2.9 then 1 end) +  count(case when np.nota_c_def_asig = 'R' then 1 end) as no_aprobados, ");
			sql.append(" count(case when np.grupo = 'HOM' then 1 end) as homologados ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? and ");
			sql.append(" np.grupo <> 'HOM' ");
			sql.append(" group by np.programa_academico, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" ) as est ");
			sql.append(" on t.programa_academico = est.programa_academico and ");
			sql.append(" pr.codigo_sede = est.codigo_sede ");
			sql.append(" where mc.matriculas is not null ");
			sql.append(" order by t.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);

			fila = stm.executeQuery();
			while (fila.next()) {
				AprobadosSedes co = new AprobadosSedes();
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setCodigo(fila.getInt("programa_academico"));
				co.setGrupos(fila.getInt("grupos"));
				co.setMatriculas(fila.getInt("matriculas"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				co.setAprobados(fila.getInt("aprobados"));
				co.setNo_aprobados(fila.getInt("no_aprobados"));
				co.setHomologados(fila.getInt("homologados"));
				co.setAsignaturas(fila.getInt("asignaturas"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* APROBADO HISTORIAL */
	@WebMethod
	public List<Aprobados> getAprobadosHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<Aprobados> can = new ArrayList<Aprobados>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.nombre_programa, ");
			sql.append(" p.programa_academico, ");
			sql.append(" g.grupos, ");
			sql.append(" mtr.matriculas, ");
			sql.append(" can.cancelaciones, ");
			sql.append(" asig.aprobados, ");
			sql.append(" asig.no_aprobados, ");
			sql.append(" asig.homologados, ");
			sql.append(" count(ma.codigo_asignatura) as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan ma ");
			sql.append(" inner join academic:acpro001.programas_academic p ");
			sql.append(" on p.programa_academico = ma.programa_academico ");
			sql.append(" left join (select asig.programa_academico, count (gru.grupo) as grupos ");
			sql.append(" from acinsed:insed001.grupos_asignatura gru ");
			sql.append(" full outer join ( ");
			sql.append(" select  pro.programa_academico, ");
			sql.append(
					" case when pro.nivel_plan between '1' and '4' and pro.programa_academico = '87' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between '5' and '6' and pro.programa_academico = '8' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in ('7','8','9','10') and pro.programa_academico = '86' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '70' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '71' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '13' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '82' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '61' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '17' then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in ('87','8','86','70','71','13','82','61','17') ");
			sql.append(" ) as asig ");
			sql.append(" on asig.asignaturas = gru.codigo_asignatura ");
			sql.append(" where gru.ano = ? ");
			sql.append(" and gru.periodo = ? ");
			sql.append(" and gru.matriculados > 0 ");
			sql.append(" group by asig.programa_academico ");
			sql.append(" ) as g ");
			sql.append(" on ma.programa_academico = g.programa_academico ");
			sql.append(" left join (SELECT m.programa_academico,count(m.codigo_asignatura) as matriculas ");
			sql.append(" from acinsed:insed001.matriculas m ");
			sql.append(" where m.ano_matric = ? and ");
			sql.append(" m.periodo_matric = ? ");
			sql.append(" group by m.programa_academico ");
			sql.append(" ) as mtr ");
			sql.append(" on ma.programa_academico = mtr.programa_academico ");
			sql.append(" left join (SELECT ca.programa_academico, ");
			sql.append(" count(ca.codigo_est) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" where ca.ano_cancel = ? and ");
			sql.append(" ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico ");
			sql.append(" ) as can ");
			sql.append(" on ma.programa_academico = can.programa_academico ");
			sql.append(" left join (select np.programa_academico, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 3.0 and 5.0 then 1 end) + count(case when np.nota_c_def_asig = 'A' then 1 end) as aprobados, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 0.0 and 2.9 then 1 end) +  count(case when np.nota_c_def_asig = 'R' then 1 end) as no_aprobados, ");
			sql.append(" count(case when np.grupo = 'HOM' then 1 end) as homologados ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? ");
			sql.append(" )as pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? and ");
			sql.append(" np.grupo <> 'HOM' ");
			sql.append(" group by np.programa_academico ");
			sql.append(" ) as asig ");
			sql.append(" on ma.programa_academico = asig.programa_academico ");
			sql.append(" where ma.plan_estudio = (select max(pro.plan_estudio) ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" where pro.programa_academico = p.programa_academico ");
			sql.append(" group by pro.programa_academico ");
			sql.append(" ) ");
			sql.append(" and mtr.matriculas is not null ");
			sql.append(
					" group by p.nombre_programa,p.programa_academico,g.grupos,mtr.matriculas,can.cancelaciones,asig.aprobados,asig.no_aprobados,asig.homologados ");
			sql.append(" order by p.nombre_programa ");
			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);

			fila = stm.executeQuery();
			while (fila.next()) {
				Aprobados co = new Aprobados();
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo(fila.getInt("programa_academico"));
				co.setGrupos(fila.getInt("grupos"));
				co.setMatriculas(fila.getInt("matriculas"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				co.setAprobados(fila.getInt("aprobados"));
				co.setNo_aprobados(fila.getInt("no_aprobados"));
				co.setHomologados(fila.getInt("homologados"));
				co.setAsignaturas(fila.getInt("asignaturas"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* APROBADO HISTORIAL SEDES */
	@WebMethod
	public List<AprobadosSedes> getAprobadosHisSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<AprobadosSedes> can = new ArrayList<AprobadosSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT distinct t.nombre_programa, ");
			sql.append(" t.programa_academico, ");
			sql.append(" pr.codigo_sede, ");
			sql.append(" t.asignaturas, ");
			sql.append(" gr.grupos, ");
			sql.append(" case when mc.matriculas is null then 0 ");
			sql.append(" else mc.matriculas ");
			sql.append(" end as matriculas, ");
			sql.append(" case when mc.cancelaciones is null then 0 ");
			sql.append(" else mc.cancelaciones ");
			sql.append(" end as cancelaciones, ");
			sql.append(" est.aprobados, ");
			sql.append(" est.no_aprobados, ");
			sql.append(" est.homologados ");
			sql.append(" from (select p.nombre_programa, ");
			sql.append(" p.programa_academico, ");
			sql.append(" count(ma.codigo_asignatura) as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan ma ");
			sql.append(" inner join academic:acpro001.programas_academic p ");
			sql.append(" on p.programa_academico = ma.programa_academico ");
			sql.append(" where ma.plan_estudio = (select max(pro.plan_estudio) ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" where pro.programa_academico = p.programa_academico ");
			sql.append(" group by pro.programa_academico ");
			sql.append(" ) ");
			sql.append(" group by p.nombre_programa,p.programa_academico ");
			sql.append(" ) as t ");
			sql.append(" inner join(select distinct pd.programa_academico,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? ");
			sql.append(" ) ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where pd.codigo_est is not null ");
			sql.append(" )as pr ");
			sql.append(" on t.programa_academico = pr.programa_academico ");
			sql.append(" left join (select asig.programa_academico, count (gru.grupo) as grupos,gru.codigo_sede ");
			sql.append(" from acinsed:insed001.grupos_asignatura gru ");
			sql.append(" full outer join ( ");
			sql.append(" select  pro.programa_academico, ");
			sql.append(
					" case when pro.nivel_plan between '1' and '4' and pro.programa_academico = '87' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between '5' and '6' and pro.programa_academico = '8' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in ('7','8','9','10') and pro.programa_academico = '86' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '70' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '71' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '13' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '82' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '61' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '17' then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in ('87','8','86','70','71','13','82','61','17') ");
			sql.append(" ) as asig ");
			sql.append(" on asig.asignaturas = gru.codigo_asignatura ");
			sql.append(" where gru.ano = ? ");
			sql.append(" and gru.periodo = ? ");
			sql.append(" and gru.matriculados > 0 ");
			sql.append(" group by asig.programa_academico,gru.codigo_sede ");
			sql.append(" ) as gr ");
			sql.append(" on t.programa_academico = gr.programa_academico and ");
			sql.append(" pr.codigo_sede = gr.codigo_sede ");
			sql.append(" left join (SELECT y.programa_academico, ");
			sql.append(" y.matriculas, ");
			sql.append(" y.codigo_sede, ");
			sql.append(" CASE WHEN k.cancelaciones IS NULL THEN 0 ");
			sql.append(" ELSE k.cancelaciones ");
			sql.append(" END AS cancelaciones ");
			sql.append(" from (select ma.programa_academico, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" count(ma.codigo_asignatura) as matriculas ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" left join (select distinct pd.codigo_est,pd.programa_academico,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico,ma.ano_matric,ma.periodo_matric, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" union ");
			sql.append(
					" select ca.programa_academico,ca.ano_cancel as ano_matric, ca.periodo_cancel as periodo_matric, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" ) as ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pd.codigo_est is not null ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ma.programa_academico and ");
			sql.append(" pro.codigo_est = ma.codigo_est ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pro.codigo_sede is not null ");
			sql.append(" group by ma.programa_academico, pro.codigo_sede ");
			sql.append(" ) as y ");
			sql.append(" full outer join(select  ca.programa_academico, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" count(ca.codigo_asignatura) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" left join (select distinct pd.codigo_est,pd.programa_academico,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico,ma.ano_matric,ma.periodo_matric, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" union ");
			sql.append(
					" select ca.programa_academico,ca.ano_cancel as ano_matric, ca.periodo_cancel as periodo_matric, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" )as ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pd.codigo_est is not null ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico and ");
			sql.append(" pro.codigo_est = ca.codigo_est ");
			sql.append(" where ca.ano_cancel = ? and ");
			sql.append(" ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico,pro.codigo_sede ");
			sql.append(" ) as k ");
			sql.append(" on k.programa_academico = y.programa_academico and ");
			sql.append(" k.codigo_sede = y.codigo_sede ");
			sql.append(" ) as mc ");
			sql.append(" on t.programa_academico = mc.programa_academico and ");
			sql.append(" pr.codigo_sede = mc.codigo_sede ");
			sql.append(" left join (select np.programa_academico, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 3.0 and 5.0 then 1 end) + count(case when np.nota_c_def_asig = 'A' then 1 end) as aprobados, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 0.0 and 2.9 then 1 end) +  count(case when np.nota_c_def_asig = 'R' then 1 end) as no_aprobados, ");
			sql.append(" count(case when np.grupo = 'HOM' then 1 end) as homologados ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join (select distinct pd.codigo_est,pd.programa_academico,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? ");
			sql.append(" ) as ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where pd.codigo_est is not null ");
			sql.append(" )as pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? and ");
			sql.append(" np.grupo <> 'HOM' ");
			sql.append(" group by np.programa_academico, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" ) as est ");
			sql.append(" on t.programa_academico = est.programa_academico and ");
			sql.append(" pr.codigo_sede = est.codigo_sede ");
			sql.append(" where gr.grupos is not null ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			stm.setInt(21, anio);
			stm.setInt(22, periodo);
			stm.setInt(23, anio);
			stm.setInt(24, periodo);

			fila = stm.executeQuery();
			while (fila.next()) {
				AprobadosSedes co = new AprobadosSedes();
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setCodigo(fila.getInt("programa_academico"));
				co.setGrupos(fila.getInt("grupos"));
				co.setMatriculas(fila.getInt("matriculas"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				co.setAprobados(fila.getInt("aprobados"));
				co.setNo_aprobados(fila.getInt("no_aprobados"));
				co.setHomologados(fila.getInt("homologados"));
				co.setAsignaturas(fila.getInt("asignaturas"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* ACADEMICO DEL SEMESTRE ACTUAL */
	@WebMethod
	public List<Academico> getAcademico(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<Academico> can = new ArrayList<Academico>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.programa_academico, ");
			sql.append(" po.nombre_programa, ");
			sql.append(" count(case when p.prome_pond_acum < 3.2 then 1 end) as menor, ");
			sql.append(" count(case when p.prome_pond_acum between 3.20 and 3.60 then 1 end) as tresdos, ");
			sql.append(" count(case when p.prome_pond_acum between 3.61 and 4.00 then 1 end) as cuatro, ");
			sql.append(" count(case when p.prome_pond_acum between 4.01 and 4.5 then 1 end) as cuatrocinco, ");
			sql.append(" count(case when p.prome_pond_acum between 4.5 and 5 then 1 end) as cinco ");
			sql.append(" from (select pro.programa_academico, ");
			sql.append(" pro.codigo_est, ");
			sql.append(" dt.prome_pond_acum ");
			sql.append(" from acinsed:insed001.programas_acad_est pro ");
			sql.append(" left join acinsed:insed001.datos_periodo_est dt ");
			sql.append(" on dt.programa_academico = pro.programa_academico and ");
			sql.append(" dt.codigo_est = pro.codigo_est and ");
			sql.append(" dt.ano_academico = pro.ano_condicion and ");
			sql.append(" dt.periodo_acad = pro.periodo_condicion ");
			sql.append(" where pro.ano_condicion = ? and ");
			sql.append(" pro.periodo_condicion = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join academic:acpro001.programas_academic po ");
			sql.append(" on po.programa_academico = p.programa_academico ");
			sql.append(" where p.prome_pond_acum is not null ");
			sql.append(" group by p.programa_academico,po.nombre_programa ");
			sql.append(" order by po.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				Academico co = new Academico();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setMenor(fila.getInt("menor"));
				co.setTresdos(fila.getInt("tresdos"));
				co.setCuatro(fila.getInt("cuatro"));
				co.setCuatrocinco(fila.getInt("cuatrocinco"));
				co.setCinco(fila.getInt("cinco"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* ACADEMICO SEMESTRE ACTUAL SEDES */
	@WebMethod
	public List<AcademicoSedes> getAcademicoSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<AcademicoSedes> can = new ArrayList<AcademicoSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.programa_academico, ");
			sql.append(" po.nombre_programa, ");
			sql.append(" p.codigo_sede, ");
			sql.append(" count(case when p.prome_pond_acum < 3.2 then 1 end) as menor, ");
			sql.append(" count(case when p.prome_pond_acum between 3.20 and 3.60 then 1 end) as tresdos, ");
			sql.append(" count(case when p.prome_pond_acum between 3.61 and 4.00 then 1 end) as cuatro, ");
			sql.append(" count(case when p.prome_pond_acum between 4.01 and 4.5 then 1 end) as cuatrocinco, ");
			sql.append(" count(case when p.prome_pond_acum between 4.5 and 5 then 1 end) as cinco ");
			sql.append(" from (select pro.programa_academico, ");
			sql.append(" pro.codigo_est, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" dt.prome_pond_acum ");
			sql.append(" from acinsed:insed001.programas_acad_est pro ");
			sql.append(" left join acinsed:insed001.datos_periodo_est dt ");
			sql.append(" on dt.programa_academico = pro.programa_academico and ");
			sql.append(" dt.codigo_est = pro.codigo_est and ");
			sql.append(" dt.ano_academico = pro.ano_condicion and ");
			sql.append(" dt.periodo_acad = pro.periodo_condicion ");
			sql.append(" where pro.ano_condicion = ? and ");
			sql.append(" pro.periodo_condicion = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join academic:acpro001.programas_academic po ");
			sql.append(" on po.programa_academico = p.programa_academico ");
			sql.append(" where p.prome_pond_acum is not null ");
			sql.append(" group by p.programa_academico,po.nombre_programa,p.codigo_sede ");
			sql.append(" order by po.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				AcademicoSedes co = new AcademicoSedes();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setMenor(fila.getInt("menor"));
				co.setTresdos(fila.getInt("tresdos"));
				co.setCuatro(fila.getInt("cuatro"));
				co.setCuatrocinco(fila.getInt("cuatrocinco"));
				co.setCinco(fila.getInt("cinco"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* ACADEMICO HISTORIAL */
	@WebMethod
	public List<Academico> getAcademicoHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<Academico> can = new ArrayList<Academico>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.programa_academico, ");
			sql.append(" po.nombre_programa, ");
			sql.append(" count(case when p.prome_pond_acum < 3.2 then 1 end) as menor, ");
			sql.append(" count(case when p.prome_pond_acum between 3.20 and 3.60 then 1 end) as tresdos, ");
			sql.append(" count(case when p.prome_pond_acum between 3.61 and 4.00 then 1 end) as cuatro, ");
			sql.append(" count(case when p.prome_pond_acum between 4.01 and 4.5 then 1 end) as cuatrocinco, ");
			sql.append(" count(case when p.prome_pond_acum between 4.5 and 5 then 1 end) as cinco ");
			sql.append(" from (select pro.programa_academico, ");
			sql.append(" pro.codigo_est, ");
			sql.append(" dt.prome_pond_acum ");
			sql.append(" from (select distinct ma.codigo_est ,ma.programa_academico,ma.ano_matric,ma.periodo_matric ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est, ");
			sql.append(" pc.ano_condicion, ");
			sql.append(" pc.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" ) as ma ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? ");
			sql.append(" ) AS pro ");
			sql.append(" left join acinsed:insed001.datos_periodo_est dt ");
			sql.append(" on dt.programa_academico = pro.programa_academico and ");
			sql.append(" dt.codigo_est = pro.codigo_est and ");
			sql.append(" dt.ano_academico = pro.ano_matric and ");
			sql.append(" dt.periodo_acad = pro.periodo_matric ");
			sql.append(" where pro.ano_matric = ? and ");
			sql.append(" pro.periodo_matric = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join academic:acpro001.programas_academic po ");
			sql.append(" on po.programa_academico = p.programa_academico ");
			sql.append(" where p.prome_pond_acum is not null ");
			sql.append(" group by p.programa_academico,po.nombre_programa ");
			sql.append(" order by po.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				Academico co = new Academico();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setMenor(fila.getInt("menor"));
				co.setTresdos(fila.getInt("tresdos"));
				co.setCuatro(fila.getInt("cuatro"));
				co.setCuatrocinco(fila.getInt("cuatrocinco"));
				co.setCinco(fila.getInt("cinco"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* ACADEMICO HISTORIAL SEDES */
	@WebMethod
	public List<AcademicoSedes> getAcademicoSedesHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<AcademicoSedes> can = new ArrayList<AcademicoSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.programa_academico, ");
			sql.append(" po.nombre_programa, ");
			sql.append(" p.codigo_sede, ");
			sql.append(" count(case when p.prome_pond_acum < 3.2 then 1 end) as menor, ");
			sql.append(" count(case when p.prome_pond_acum between 3.20 and 3.60 then 1 end) as tresdos, ");
			sql.append(" count(case when p.prome_pond_acum between 3.61 and 4.00 then 1 end) as cuatro, ");
			sql.append(" count(case when p.prome_pond_acum between 4.01 and 4.5 then 1 end) as cuatrocinco, ");
			sql.append(" count(case when p.prome_pond_acum between 4.5 and 5 then 1 end) as cinco ");
			sql.append(" from (select pro.programa_academico, ");
			sql.append(" pro.codigo_est, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" dt.prome_pond_acum ");
			sql.append(
					" from (select distinct ma.codigo_est ,ma.programa_academico,ma.ano_matric,ma.periodo_matric,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est, ");
			sql.append(" pc.ano_condicion, ");
			sql.append(" pc.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" ) as ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pd.codigo_sede is not null ");
			sql.append(" ) AS pro ");
			sql.append(" left join acinsed:insed001.datos_periodo_est dt ");
			sql.append(" on dt.programa_academico = pro.programa_academico and ");
			sql.append(" dt.codigo_est = pro.codigo_est and ");
			sql.append(" dt.ano_academico = pro.ano_matric and ");
			sql.append(" dt.periodo_acad = pro.periodo_matric ");
			sql.append(" where pro.ano_matric = ? and ");
			sql.append(" pro.periodo_matric = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join academic:acpro001.programas_academic po ");
			sql.append(" on po.programa_academico = p.programa_academico ");
			sql.append(" where p.prome_pond_acum is not null ");
			sql.append(" group by p.programa_academico,po.nombre_programa,p.codigo_sede ");
			sql.append(" order by po.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);

			fila = stm.executeQuery();
			while (fila.next()) {
				AcademicoSedes co = new AcademicoSedes();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setMenor(fila.getInt("menor"));
				co.setTresdos(fila.getInt("tresdos"));
				co.setCuatro(fila.getInt("cuatro"));
				co.setCuatrocinco(fila.getInt("cuatrocinco"));
				co.setCinco(fila.getInt("cinco"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* CANCELACIONES SEMESTRE ACTUAL Y HISTORIAL */
	@WebMethod
	public List<Cancelaciones> getCancelaciones(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<Cancelaciones> can = new ArrayList<Cancelaciones>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT ca.programa_academico, ");
			sql.append(" pa.nombre_programa, ");
			sql.append(" count(ca.programa_academico) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" inner join academic:acpro001.programas_academic pa ");
			sql.append(" on pa.programa_academico  = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico, pa.nombre_programa ");
			sql.append(" order by pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				Cancelaciones co = new Cancelaciones();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* CANCELACIONES SEMESTRE ACTUAL Y HISTORIAL SEDES */
	@WebMethod
	public List<CancelacionesSedes> getCancelacionesSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int anio1 = anio + 1;
		List<CancelacionesSedes> can = new ArrayList<CancelacionesSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT ca.programa_academico, ");
			sql.append(" pa.nombre_programa, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" count(ca.codigo_asignatura) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" where pr.ano_condicion between ? and ? ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico and ");
			sql.append(" pro.codigo_est = ca.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic pa ");
			sql.append(" on pa.programa_academico = ca.programa_academico ");
			sql.append(" where ca.ano_cancel = ? and ");
			sql.append(" ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico, pa.nombre_programa, pro.codigo_sede ");
			sql.append(" order by pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, anio1);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				CancelacionesSedes co = new CancelacionesSedes();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* MOTIVOS SEMESTRE ACTUAL Y HISTORIAL */
	@WebMethod
	public List<Motivos> getMotivos(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<Motivos> can = new ArrayList<Motivos>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT cu.descripcion_causa, ");
			sql.append(" count(ca.causa_cancel_asig) as causa ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" inner join academic:acpro001.causas_cancel_asig cu ");
			sql.append(" on cu.causa_cancel_asig = ca.causa_cancel_asig ");
			sql.append(" where ca.ano_cancel = ? and ");
			sql.append(" ca.periodo_cancel = ? ");
			sql.append(" group by cu.descripcion_causa ");
			sql.append(" order by cu.descripcion_causa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				Motivos co = new Motivos();
				co.setNombre(fila.getString("descripcion_causa"));
				co.setCausa(fila.getInt("causa"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* MOTIVOS SEMESTRE ACTUAL Y HISTORIAL SEDES */
	@WebMethod
	public List<MotivosSedes> getMotivosSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int anio1 = anio + 1;
		List<MotivosSedes> can = new ArrayList<MotivosSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT cu.descripcion_causa, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" count(ca.causa_cancel_asig) as causa ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" where pr.ano_condicion between ? and ? ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico and ");
			sql.append(" pro.codigo_est = ca.codigo_est ");
			sql.append(" inner join academic:acpro001.causas_cancel_asig cu ");
			sql.append(" on cu.causa_cancel_asig = ca.causa_cancel_asig ");
			sql.append(" where ca.ano_cancel = ? and ");
			sql.append(" ca.periodo_cancel = ? ");
			sql.append(" group by cu.descripcion_causa, pro.codigo_sede ");
			sql.append(" order by cu.descripcion_causa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, anio1);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				MotivosSedes co = new MotivosSedes();
				co.setNombre(fila.getString("descripcion_causa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setCausa(fila.getInt("causa"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* PROGRAMAS SEMESTRE ACTUAL */
	@WebMethod
	public List<Programas> getProgramas(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<Programas> can = new ArrayList<Programas>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT distinct p.codigo_asignatura, ");
			sql.append(" a.nombre_asignatura, ");
			sql.append(" p.grupo, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" max(pr.plan_estudio) as pla_estudio, ");
			sql.append(" case when m.cupos_matriculados is null then 0 ");
			sql.append(" else m.cupos_matriculados ");
			sql.append(" end as cupos_matriculados, ");
			sql.append(" case when c.cancelaciones is null then 0 ");
			sql.append(" else c.cancelaciones ");
			sql.append(" end as cancelaciones, ");
			sql.append(" case when ap.aprobados is null then 0 ");
			sql.append(" else ap.aprobados ");
			sql.append(" end as aprobados, ");
			sql.append(" case when ap.no_aprobados is null then 0 ");
			sql.append(" else ap.no_aprobados ");
			sql.append(" end as no_aprobados, ");
			sql.append(" case when ap.homologados is null then 0 ");
			sql.append(" else ap.homologados ");
			sql.append(" end as homologados ");
			sql.append(" from (select ma.programa_academico, ");
			sql.append(" ma.codigo_asignatura, ");
			sql.append(" ma.grupo ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_asignatura, ");
			sql.append(" ca.grupo ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est and ");
			sql.append(" pro.ano_condicion = np.ano_matric and ");
			sql.append(" pro.periodo_condicion = np.periodo_matric ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura  ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as pr ");
			sql.append(" on pr.asignaturas = p.codigo_asignatura ");
			sql.append(" inner join academic:acpro001.asignaturas a ");
			sql.append(" on a.codigo_asignatura = p.codigo_asignatura ");
			sql.append(
					" left join (select asig.programa_academico,gru.codigo_asignatura,gru.matriculados as cupos_matriculados,gru.grupo ");
			sql.append(" from acinsed:insed001.grupos_asignatura gru ");
			sql.append(" full outer join ( ");
			sql.append(" select  pro.programa_academico, ");
			sql.append(
					" case when pro.nivel_plan between '1' and '4' and pro.programa_academico = '87' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between '5' and '6' and pro.programa_academico = '8' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in ('7','8','9','10') and pro.programa_academico = '86' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '70' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '71' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '13' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '82' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '61' then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in ('87','8','86','70','71','13','82','61') ");
			sql.append(" ) as asig ");
			sql.append(" on asig.asignaturas = gru.codigo_asignatura ");
			sql.append(" where gru.ano = ? ");
			sql.append(" and gru.periodo = ? ");
			sql.append(" and gru.matriculados > 0 ");
			sql.append(" and asig.programa_academico is not null ");
			sql.append(" ) as m ");
			sql.append(" on ");
			sql.append(" m.codigo_asignatura = p.codigo_asignatura and ");
			sql.append(" m.grupo = p.grupo ");
			sql.append(" left join (select ca.programa_academico, ");
			sql.append(" ca.codigo_asignatura, ");
			sql.append(" ca.grupo, ");
			sql.append(" count(ca.codigo_asignatura) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico,ca.codigo_asignatura,ca.grupo ");
			sql.append(" ) as c ");
			sql.append(" on ");
			sql.append(" c.codigo_asignatura = p.codigo_asignatura and");
			sql.append(" c.grupo = p.grupo ");
			sql.append(" left join (select np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 3.0 and 5.0 then 1 end) + count(case when np.nota_c_def_asig = 'A' then 1 end) as aprobados, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 0.0 and 2.9 then 1 end) +  count(case when np.nota_c_def_asig = 'R' then 1 end) as no_aprobados, ");
			sql.append(" count(case when np.grupo = 'HOM' then 1 end) as homologados ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? ");
			sql.append(" group by np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo ");
			sql.append(" ) as ap ");
			sql.append(" on ");
			sql.append(" ap.codigo_asignatura = p.codigo_asignatura and");
			sql.append(" ap.grupo = p.grupo ");
			sql.append(" where p.grupo <> '.' ");
			sql.append(" group by p.codigo_asignatura, ");
			sql.append(" p.grupo, ");
			sql.append(" a.nombre_asignatura, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" cupos_matriculados, ");
			sql.append(" cancelaciones, ");
			sql.append(" aprobados, ");
			sql.append(" no_aprobados, ");
			sql.append(" homologados ");
			sql.append(" order by p.codigo_asignatura ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				Programas co = new Programas();
				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setNombre(fila.getString("nombre_asignatura"));
				co.setGrupo(fila.getString("grupo"));
				co.setCodigo_programa(fila.getInt("programa_academico"));
				co.setPla_estudio(fila.getInt("pla_estudio"));
				co.setCupos_matriculados(fila.getInt("cupos_matriculados"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				co.setAprobados(fila.getInt("aprobados"));
				co.setNo_aprobados(fila.getInt("no_aprobados"));
				co.setHomologados(fila.getInt("homologados"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e)

			{
				e.printStackTrace();
			}
		}

		return can;
	}

	/* PROGRAMAS SEMESTRE ACTUAL SEDES */
	@WebMethod
	public List<ProgramasSedes> getProgramasSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int anio1 = anio + 1;
		List<ProgramasSedes> can = new ArrayList<ProgramasSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.codigo_asignatura, ");
			sql.append(" a.nombre_asignatura, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" max(pr.plan_estudio) as pla_estudio, ");
			sql.append(" p.codigo_sede, ");
			sql.append(" p.grupo, ");
			sql.append(" case when m.cupos_matriculados is null then 0 ");
			sql.append(" else m.cupos_matriculados ");
			sql.append(" end as cupos_matriculados, ");
			sql.append(" case when c.cancelaciones is null then 0 ");
			sql.append(" else c.cancelaciones ");
			sql.append(" end as cancelaciones, ");
			sql.append(" case when ap.aprobados is null then 0 ");
			sql.append(" else ap.aprobados ");
			sql.append(" end as aprobados, ");
			sql.append(" case when ap.no_aprobados is null then 0 ");
			sql.append(" else ap.no_aprobados ");
			sql.append(" end as no_aprobados, ");
			sql.append(" case when ap.homologados is null then 0 ");
			sql.append(" else ap.homologados ");
			sql.append(" end as homologados ");
			sql.append(" from (select ma.programa_academico, ");
			sql.append(" ma.codigo_asignatura, ");
			sql.append(" ma.grupo, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ma.programa_academico and ");
			sql.append(" pro.codigo_est = ma.codigo_est ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pro.codigo_sede is not null ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico as programa_academico, ");
			sql.append(" ca.codigo_asignatura as codigo_asignatura, ");
			sql.append(" ca.grupo, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico and ");
			sql.append(" pro.codigo_est = ca.codigo_est ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est and ");
			sql.append(" pro.ano_condicion = np.ano_matric and ");
			sql.append(" pro.periodo_condicion = np.periodo_matric ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as pr ");
			sql.append(" on pr.asignaturas = p.codigo_asignatura ");
			sql.append(" inner join asignaturas a ");
			sql.append(" on a.codigo_asignatura = p.codigo_asignatura ");
			sql.append(
					" left join (select asig.programa_academico,gru.codigo_asignatura,gru.matriculados as cupos_matriculados,gru.grupo,gru.codigo_sede ");
			sql.append(" from acinsed:insed001.grupos_asignatura gru ");
			sql.append(" full outer join ( ");
			sql.append(" select  pro.programa_academico, ");
			sql.append(
					" case when pro.nivel_plan between '1' and '4' and pro.programa_academico = '87' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between '5' and '6' and pro.programa_academico = '8' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in ('7','8','9','10') and pro.programa_academico = '86' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '70' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '71' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '13' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '82' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '61' then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in ('87','8','86','70','71','13','82','61') ");
			sql.append(" ) as asig ");
			sql.append(" on asig.asignaturas = gru.codigo_asignatura ");
			sql.append(" where gru.ano = ? ");
			sql.append(" and gru.periodo = ? ");
			sql.append(" and gru.matriculados > 0 ");
			sql.append(" and asig.programa_academico is not null ");
			sql.append(" ) as m ");
			sql.append(" on m.grupo = p.grupo and ");
			sql.append(" m.codigo_asignatura = p.codigo_asignatura and ");
			sql.append(" m.codigo_sede = p.codigo_sede ");
			sql.append(" left join (select ca.programa_academico, ");
			sql.append(" ca.codigo_asignatura, ");
			sql.append(" ca.grupo, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" count(ca.codigo_asignatura) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" where pr.ano_condicion between ? and ? ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico and ");
			sql.append(" pro.codigo_est = ca.codigo_est ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico,ca.codigo_asignatura,ca.grupo, pro.codigo_sede ");
			sql.append(" ) as c ");
			sql.append(" on c.grupo = p.grupo and ");
			sql.append(" c.codigo_asignatura = p.codigo_asignatura and ");
			sql.append(" c.codigo_sede = p.codigo_sede ");
			sql.append(" left join (select np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 3.0 and 5.0 then 1 end) + count(case when np.nota_c_def_asig = 'A' then 1 end) as aprobados, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 0.0 and 2.9 then 1 end) +  count(case when np.nota_c_def_asig = 'R' then 1 end) as no_aprobados, ");
			sql.append(" count(case when np.grupo = 'HOM' then 1 end) as homologados ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? ");
			sql.append(" group by np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" ) as ap ");
			sql.append(" on ap.grupo = p.grupo and ");
			sql.append(" ap.codigo_asignatura = p.codigo_asignatura and ");
			sql.append(" ap.codigo_sede = p.codigo_sede ");
			sql.append(" where p.grupo <> '.' ");
			sql.append(" group by p.codigo_asignatura, ");
			sql.append(" a.nombre_asignatura, ");
			sql.append(" p.grupo, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" p.codigo_sede, ");
			sql.append(" cupos_matriculados, ");
			sql.append(" cancelaciones, ");
			sql.append(" aprobados, ");
			sql.append(" no_aprobados, ");
			sql.append(" homologados ");
			sql.append(" order by p.codigo_asignatura ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, anio1);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				ProgramasSedes co = new ProgramasSedes();

				co.setCodigo_sede(fila.getInt("codigo_sede"));

				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setNombre(fila.getString("nombre_asignatura"));
				co.setGrupo(fila.getString("grupo"));
				co.setCodigo_programa(fila.getInt("programa_academico"));
				co.setPla_estudio(fila.getInt("pla_estudio"));
				co.setCupos_matriculados(fila.getInt("cupos_matriculados"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				co.setAprobados(fila.getInt("aprobados"));
				co.setNo_aprobados(fila.getInt("no_aprobados"));
				co.setHomologados(fila.getInt("homologados"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e)

			{
				e.printStackTrace();
			}
		}

		return can;
	}

	/* PROGRAMAS HISTORIAL */
	@WebMethod
	public List<Programas> getProgramasHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<Programas> can = new ArrayList<Programas>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT distinct p.codigo_asignatura, ");
			sql.append(" a.nombre_asignatura, ");
			sql.append(" p.grupo, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" max(pr.plan_estudio) as pla_estudio, ");
			sql.append(" case when m.cupos_matriculados is null then 0 ");
			sql.append(" else m.cupos_matriculados ");
			sql.append(" end as cupos_matriculados, ");
			sql.append(" case when c.cancelaciones is null then 0 ");
			sql.append(" else c.cancelaciones ");
			sql.append(" end as cancelaciones, ");
			sql.append(" case when ap.aprobados is null then 0 ");
			sql.append(" else ap.aprobados ");
			sql.append(" end as aprobados, ");
			sql.append(" case when ap.no_aprobados is null then 0 ");
			sql.append(" else ap.no_aprobados ");
			sql.append(" end as no_aprobados, ");
			sql.append(" case when ap.homologados is null then 0 ");
			sql.append(" else ap.homologados ");
			sql.append(" end as homologados ");
			sql.append(" from (select ma.programa_academico, ");
			sql.append(" ma.grupo, ");
			sql.append(" ma.codigo_asignatura ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.grupo, ");
			sql.append(" ca.codigo_asignatura ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select np.programa_academico, ");
			sql.append(" np.grupo, ");
			sql.append(" np.codigo_asignatura ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est and ");
			sql.append(" pro.ano_condicion = np.ano_matric and ");
			sql.append(" pro.periodo_condicion = np.periodo_matric ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as pr ");
			sql.append(" on pr.asignaturas = p.codigo_asignatura ");
			sql.append(" inner join academic:acpro001.asignaturas a ");
			sql.append(" on a.codigo_asignatura = p.codigo_asignatura ");
			sql.append(
					" left join (select asig.programa_academico,gru.codigo_asignatura,gru.matriculados as cupos_matriculados,gru.grupo ");
			sql.append(" from acinsed:insed001.grupos_asignatura gru ");
			sql.append(" full outer join ( ");
			sql.append(" select  pro.programa_academico, ");
			sql.append(
					" case when pro.nivel_plan between '1' and '4' and pro.programa_academico = '87' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between '5' and '6' and pro.programa_academico = '8' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in ('7','8','9','10') and pro.programa_academico = '86' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '70' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '71' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '13' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '82' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '61' then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in ('87','8','86','70','71','13','82','61') ");
			sql.append(" ) as asig ");
			sql.append(" on asig.asignaturas = gru.codigo_asignatura ");
			sql.append(" where gru.ano = ? ");
			sql.append(" and gru.periodo = ? ");
			sql.append(" and gru.matriculados > 0 ");
			sql.append(" and asig.programa_academico is not null ");
			sql.append(" ) as m ");
			sql.append(" on m.grupo = p.grupo and ");
			sql.append(" m.codigo_asignatura = p.codigo_asignatura ");
			sql.append(" left join (select ca.programa_academico, ");
			sql.append(" ca.grupo, ");
			sql.append(" ca.codigo_asignatura, ");
			sql.append(" count(ca.codigo_asignatura) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico,ca.grupo,ca.codigo_asignatura ");
			sql.append(" ) as c ");
			sql.append(" on c.grupo = p.grupo and ");
			sql.append(" c.codigo_asignatura = p.codigo_asignatura ");
			sql.append(" left join (select np.programa_academico, ");
			sql.append(" np.grupo, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 3.0 and 5.0 then 1 end) + count(case when np.nota_c_def_asig = 'A' then 1 end) as aprobados, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 0.0 and 2.9 then 1 end) +  count(case when np.nota_c_def_asig = 'R' then 1 end) as no_aprobados, ");
			sql.append(" count(case when np.grupo = 'HOM' then 1 end) as homologados ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join (select distinct ma.codigo_est,ma.programa_academico ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est, ");
			sql.append(" pc.ano_condicion, ");
			sql.append(" pc.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" ) as ma ");
			sql.append(" )as pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? ");
			sql.append(" group by np.programa_academico, ");
			sql.append(" np.grupo, ");
			sql.append(" np.codigo_asignatura ");
			sql.append(" ) as ap ");
			sql.append(" on ap.grupo = p.grupo and ");
			sql.append(" ap.codigo_asignatura = p.codigo_asignatura ");
			sql.append(" where p.grupo <> '.' ");
			sql.append(" group by p.grupo, ");
			sql.append(" p.codigo_asignatura, ");
			sql.append(" a.nombre_asignatura, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" cupos_matriculados, ");
			sql.append(" cancelaciones, ");
			sql.append(" aprobados, ");
			sql.append(" no_aprobados, ");
			sql.append(" homologados ");
			sql.append("  order by p.codigo_asignatura ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				Programas co = new Programas();

				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setNombre(fila.getString("nombre_asignatura"));
				co.setGrupo(fila.getString("grupo"));
				co.setCodigo_programa(fila.getInt("programa_academico"));
				co.setPla_estudio(fila.getInt("pla_estudio"));
				co.setCupos_matriculados(fila.getInt("cupos_matriculados"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				co.setAprobados(fila.getInt("aprobados"));
				co.setNo_aprobados(fila.getInt("no_aprobados"));
				co.setHomologados(fila.getInt("homologados"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e)

			{
				e.printStackTrace();
			}
		}

		return can;
	}

	/* PROGRAMAS HISTORIAL SEDES */
	@WebMethod
	public List<ProgramasSedes> getProgramasSedesHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<ProgramasSedes> can = new ArrayList<ProgramasSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT p.codigo_asignatura, ");
			sql.append(" p.grupo, ");
			sql.append(" a.nombre_asignatura, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" max(pr.plan_estudio) as pla_estudio, ");
			sql.append(" p.codigo_sede, ");
			sql.append(" case when m.cupos_matriculados is null then 0 ");
			sql.append(" else m.cupos_matriculados ");
			sql.append(" end as cupos_matriculados, ");
			sql.append(" case when c.cancelaciones is null then 0 ");
			sql.append(" else c.cancelaciones ");
			sql.append(" end as cancelaciones, ");
			sql.append(" case when ap.aprobados is null then 0 ");
			sql.append(" else ap.aprobados ");
			sql.append(" end as aprobados, ");
			sql.append(" case when ap.no_aprobados is null then 0 ");
			sql.append(" else ap.no_aprobados ");
			sql.append(" end as no_aprobados, ");
			sql.append(" case when ap.homologados is null then 0 ");
			sql.append(" else ap.homologados ");
			sql.append(" end as homologados ");
			sql.append(" from (select ma.programa_academico, ");
			sql.append(" ma.codigo_asignatura, ");
			sql.append(" ma.grupo, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" left join (select distinct pd.codigo_est,pd.programa_academico,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico,ma.ano_matric,ma.periodo_matric, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" union ");
			sql.append(
					" select ca.programa_academico,ca.ano_cancel as ano_matric, ca.periodo_cancel as periodo_matric, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" ) ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pd.codigo_est is not null ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ma.programa_academico and ");
			sql.append(" pro.codigo_est = ma.codigo_est ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pro.codigo_sede is not null ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico as programa_academico, ");
			sql.append(" ca.codigo_asignatura as codigo_asignatura, ");
			sql.append(" ca.grupo, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" left join (select distinct pd.codigo_est,pd.programa_academico,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico,ma.ano_matric,ma.periodo_matric, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" union ");
			sql.append(
					" select ca.programa_academico,ca.ano_cancel as ano_matric, ca.periodo_cancel as periodo_matric, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" ) ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pd.codigo_est is not null ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico and ");
			sql.append(" pro.codigo_est = ca.codigo_est ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est and ");
			sql.append(" pro.ano_condicion = np.ano_matric and ");
			sql.append(" pro.periodo_condicion = np.periodo_matric ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as pr ");
			sql.append(" on pr.asignaturas = p.codigo_asignatura ");
			sql.append(" inner join academic:acpro001.asignaturas a ");
			sql.append(" on a.codigo_asignatura = p.codigo_asignatura ");
			sql.append(
					" left join (select asig.programa_academico,gru.codigo_asignatura,gru.matriculados as cupos_matriculados,gru.grupo,gru.codigo_sede ");
			sql.append(" from acinsed:insed001.grupos_asignatura gru ");
			sql.append(" full outer join ( ");
			sql.append(" select  pro.programa_academico, ");
			sql.append(
					" case when pro.nivel_plan between '1' and '4' and pro.programa_academico = '87' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between '5' and '6' and pro.programa_academico = '8' then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in ('7','8','9','10') and pro.programa_academico = '86' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '70' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '71' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '13' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '82' then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = '61' then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in ('87','8','86','70','71','13','82','61') ");
			sql.append(" ) as asig ");
			sql.append(" on asig.asignaturas = gru.codigo_asignatura ");
			sql.append(" where gru.ano = ? ");
			sql.append(" and gru.periodo = ? ");
			sql.append(" and gru.matriculados > 0 ");
			sql.append(" and asig.programa_academico is not null ");
			sql.append(" ) as m ");
			sql.append(" on m.grupo = p.grupo and ");
			sql.append(" m.codigo_asignatura = p.codigo_asignatura and ");
			sql.append(" m.codigo_sede = p.codigo_sede ");
			sql.append(" left join (select ca.programa_academico, ");
			sql.append(" ca.codigo_asignatura, ");
			sql.append(" ca.grupo, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" count(ca.codigo_asignatura) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(" left join (select distinct pd.codigo_est,pd.programa_academico,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico,ma.ano_matric,ma.periodo_matric, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" union ");
			sql.append(
					" select ca.programa_academico,ca.ano_cancel as ano_matric, ca.periodo_cancel as periodo_matric, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" ) ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pd.codigo_est is not null ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico and ");
			sql.append(" pro.codigo_est = ca.codigo_est ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico,ca.codigo_asignatura,ca.grupo, pro.codigo_sede ");
			sql.append(" ) as c ");
			sql.append(" on c.grupo = p.grupo and ");
			sql.append(" c.codigo_asignatura = p.codigo_asignatura and ");
			sql.append(" c.codigo_sede = p.codigo_sede ");
			sql.append(" left join (select np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 3.0 and 5.0 then 1 end) + count(case when np.nota_c_def_asig = 'A' then 1 end) as aprobados, ");
			sql.append(
					" count(case when np.nota_n_def_asig between 0.0 and 2.9 then 1 end) +  count(case when np.nota_c_def_asig = 'R' then 1 end) as no_aprobados, ");
			sql.append(" count(case when np.grupo = 'HOM' then 1 end) as homologados ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join (select distinct pd.codigo_est,pd.programa_academico,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? ");
			sql.append(" ) as ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where pd.codigo_est is not null ");
			sql.append(" )as pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" where np.ano_matric = ? and ");
			sql.append(" np.periodo_matric = ? ");
			sql.append(" group by np.programa_academico, ");
			sql.append(" np.codigo_asignatura, ");
			sql.append(" np.grupo, ");
			sql.append(" pro.codigo_sede ");
			sql.append(" ) as ap ");
			sql.append(" on ap.programa_academico = p.programa_academico and ");
			sql.append(" ap.codigo_asignatura = p.codigo_asignatura and ");
			sql.append(" ap.codigo_sede = p.codigo_sede ");
			sql.append(" where p.grupo <> '.' ");
			sql.append(" group by p.grupo, ");
			sql.append(" p.codigo_asignatura, ");
			sql.append(" a.nombre_asignatura, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" p.codigo_sede, ");
			sql.append(" cupos_matriculados, ");
			sql.append(" cancelaciones, ");
			sql.append(" aprobados, ");
			sql.append(" no_aprobados, ");
			sql.append(" homologados ");
			sql.append(" order by p.codigo_asignatura ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			stm.setInt(13, anio);
			stm.setInt(14, periodo);
			stm.setInt(15, anio);
			stm.setInt(16, periodo);
			stm.setInt(17, anio);
			stm.setInt(18, periodo);
			stm.setInt(19, anio);
			stm.setInt(20, periodo);
			stm.setInt(21, anio);
			stm.setInt(22, periodo);
			stm.setInt(23, anio);
			stm.setInt(24, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				ProgramasSedes co = new ProgramasSedes();
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setNombre(fila.getString("nombre_asignatura"));
				co.setGrupo(fila.getString("grupo"));
				co.setCodigo_programa(fila.getInt("programa_academico"));
				co.setPla_estudio(fila.getInt("pla_estudio"));
				co.setCupos_matriculados(fila.getInt("cupos_matriculados"));
				co.setCancelaciones(fila.getInt("cancelaciones"));
				co.setAprobados(fila.getInt("aprobados"));
				co.setNo_aprobados(fila.getInt("no_aprobados"));
				co.setHomologados(fila.getInt("homologados"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e)

			{
				e.printStackTrace();
			}
		}

		return can;
	}

	/* HISTORICO DEL SEMESTRE */
	@WebMethod
	public List<HisSemestre> getHisSemestre(int anio) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 6;
		List<HisSemestre> can = new ArrayList<HisSemestre>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT a.ano, ");
			sql.append(" a.periodo, ");
			sql.append(" k.estudiantes, ");
			sql.append(" count(case when a.perdidas = 1 then 1 end) as segundados, ");
			sql.append(" count(case when a.perdidas = 2 then 1 end) as entercerados, ");
			sql.append(" count(case when a.perdidas = 3 then 1 end) as encuartados ");
			sql.append(" from (select t.ano, ");
			sql.append(" max(p.periodo_matric) as periodo, ");
			sql.append(" t.codigo_est, ");
			sql.append(" max(t.perdidas) as perdidas ");
			sql.append(" from(select max(n.ano_matric) as ano, ");
			sql.append(" n.codigo_est, ");
			sql.append(" count (n.codigo_asignatura) as perdidas, ");
			sql.append(" n.codigo_asignatura ");
			sql.append(" from (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM ");
			sql.append(" acinsed:insed001.notas_periodo_est dp2 ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE ");
			sql.append(" dp2.nota_n_def_asig between 0.0 and 2.9 or ");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as n ");
			sql.append(" group by n.codigo_est, n.codigo_asignatura ");
			sql.append(" ) as t ");
			sql.append(" inner join (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM acinsed:insed001.notas_periodo_est dp2");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE dp2.nota_n_def_asig between 0.0 and 2.9 or");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as p ");
			sql.append(" on p.ano_matric = t.ano and ");
			sql.append(" p.codigo_asignatura = t.codigo_asignatura and ");
			sql.append(" p.codigo_est = t.codigo_est ");
			sql.append(" group by t.ano, ");
			sql.append(" t.codigo_est ");
			sql.append(" ) as a ");
			sql.append(" inner join (select ma.ano_matric, ");
			sql.append(" ma.periodo_matric, ");
			sql.append(" sum(matriculas + cancelaciones) as estudiantes ");
			sql.append(" from ( select count(distinct ma.codigo_est) as matriculas, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric between ? and ? ");
			sql.append(" group by ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" ) as ma ");
			sql.append(" left join (select count(ca.codigo_est) as cancelaciones, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel between ? and ? ");
			sql.append(" group by ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" ) as c ");
			sql.append(" on c.periodo_cancel = ma.periodo_matric ");
			sql.append(" and c.ano_cancel = ma.ano_matric ");
			sql.append(" group by ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" ) as k ");
			sql.append(" on k.ano_matric = a.ano and ");
			sql.append(" k.periodo_matric = a.periodo ");
			sql.append(" group by a.ano, a.periodo, k.estudiantes ");
			sql.append(" order by a.ano, a.periodo ");
			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, ann);
			stm.setInt(2, anio);
			stm.setInt(3, ann);
			stm.setInt(4, anio);
			fila = stm.executeQuery();
			while (fila.next()) {
				HisSemestre co = new HisSemestre();
				co.setAno(fila.getInt("ano"));
				co.setPeriodo(fila.getInt("periodo"));
				co.setEstudiantes(fila.getInt("estudiantes"));
				co.setSegundados(fila.getInt("segundados"));
				co.setEntercerados(fila.getInt("entercerados"));
				co.setEncuartados(fila.getInt("encuartados"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* HISTORICO DEL SEMESTRE SEDES */
	@WebMethod
	public List<HisSemestreSede> getHisSemestreSedes(int anio) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 6;
		List<HisSemestreSede> can = new ArrayList<HisSemestreSede>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT a.ano, ");
			sql.append(" a.periodo, ");
			sql.append(" a.codigo_sede, ");
			sql.append(" k.estudiantes, ");
			sql.append(" count(case when a.perdidas = 1 then 1 end) as segundados, ");
			sql.append(" count(case when a.perdidas = 2 then 1 end) as entercerados, ");
			sql.append(" count(case when a.perdidas = 3 then 1 end) as encuartados ");
			sql.append(" from (select t.ano, ");
			sql.append(" max(p.periodo_matric) as periodo, ");
			sql.append(" t.codigo_est, ");
			sql.append(" max(t.perdidas) as perdidas, ");
			sql.append(" t.codigo_sede ");
			sql.append(" from(select max(n.ano_matric) as ano, ");
			sql.append(" n.codigo_est, ");
			sql.append(" count (n.codigo_asignatura) as perdidas, ");
			sql.append(" n.codigo_sede, ");
			sql.append(" n.codigo_asignatura ");
			sql.append(" from (select distinct dp2.periodo_matric, ");
			sql.append(
					" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura,prog.codigo_sede ");
			sql.append(" FROM ");
			sql.append(" acinsed:insed001.notas_periodo_est dp2 ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" inner join acinsed:insed001.programas_acad_est prog ");
			sql.append(" on prog.programa_academico = dp2.programa_academico and ");
			sql.append(" prog.codigo_est = dp2.codigo_est ");
			sql.append(" WHERE ");
			sql.append(" dp2.nota_n_def_asig between 0.0 and 2.9 or ");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as n ");
			sql.append(" group by n.codigo_est, n.codigo_asignatura,n.codigo_sede ");
			sql.append(" ) as t ");
			sql.append(" inner join (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM acinsed:insed001.notas_periodo_est dp2");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE dp2.nota_n_def_asig between 0.0 and 2.9 or");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as p ");
			sql.append(" on p.ano_matric = t.ano and ");
			sql.append(" p.codigo_asignatura = t.codigo_asignatura and ");
			sql.append(" p.codigo_est = t.codigo_est ");
			sql.append(" group by t.ano, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.codigo_sede ");
			sql.append(" ) as a ");
			sql.append(" inner join (select m.ano_matric, ");
			sql.append(" m.periodo_matric, ");
			sql.append(" m.codigo_sede, ");
			sql.append(" count (m.codigo_est) as estudiantes ");
			sql.append(" from (select distinct ma.codigo_est,ma.ano_matric,ma.periodo_matric,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric between ? and ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel between ? and ? ");
			sql.append(" ) as ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric between ? and ? and ");
			sql.append(" pd.codigo_sede is not null ");
			sql.append(" )as m ");
			sql.append(" group by m.ano_matric, ");
			sql.append(" m.periodo_matric, ");
			sql.append(" m.codigo_sede ");
			sql.append(" ) as k ");
			sql.append(" on k.ano_matric = a.ano and ");
			sql.append(" k.periodo_matric = a.periodo and");
			sql.append(" k.codigo_sede = a.codigo_sede ");
			sql.append(" group by a.ano, a.periodo, k.estudiantes,a.codigo_sede ");
			sql.append(" order by a.ano, a.periodo");
			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, ann);
			stm.setInt(2, anio);
			stm.setInt(3, ann);
			stm.setInt(4, anio);
			stm.setInt(5, ann);
			stm.setInt(6, anio);
			fila = stm.executeQuery();
			while (fila.next()) {
				HisSemestreSede co = new HisSemestreSede();
				co.setAno(fila.getInt("ano"));
				co.setPeriodo(fila.getInt("periodo"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setEstudiantes(fila.getInt("estudiantes"));
				co.setSegundados(fila.getInt("segundados"));
				co.setEntercerados(fila.getInt("entercerados"));
				co.setEncuartados(fila.getInt("encuartados"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* HISTORICO PROGRAMAS */
	@WebMethod
	public List<HisProgramas> getHisProgramas(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<HisProgramas> can = new ArrayList<HisProgramas>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT a.programa_academico, ");
			sql.append(" pg.nombre_programa, ");
			sql.append(" k.estudiantes, ");
			sql.append(" count(case when a.perdidas = 1 then 1 end) as segundados, ");
			sql.append(" count(case when a.perdidas = 2 then 1 end) as entercerados, ");
			sql.append(" count(case when a.perdidas = 3 then 1 end) as encuartados ");
			sql.append(" from (select t.ano, ");
			sql.append(" max(p.periodo_matric) as periodo, ");
			sql.append(" t.codigo_est, ");
			sql.append(" max(t.perdidas) as perdidas, ");
			sql.append(" t.programa_academico ");
			sql.append(" from(select max(n.ano_matric) as ano, ");
			sql.append(" n.codigo_est, ");
			sql.append(" count (n.codigo_asignatura) as perdidas, ");
			sql.append(" n.programa_academico, ");
			sql.append(" n.codigo_asignatura ");
			sql.append(" from (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM ");
			sql.append(" acinsed:insed001.notas_periodo_est dp2 ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE ");
			sql.append(" dp2.nota_n_def_asig between 0.0 and 2.9 or ");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as n ");
			sql.append(" group by n.codigo_est, n.codigo_asignatura,n.programa_academico ");
			sql.append(" ) as t ");
			sql.append(" inner join (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM acinsed:insed001.notas_periodo_est dp2");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE dp2.nota_n_def_asig between 0.0 and 2.9 or");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as p ");
			sql.append(" on p.ano_matric = t.ano and ");
			sql.append(" p.codigo_asignatura = t.codigo_asignatura and ");
			sql.append(" p.codigo_est = t.codigo_est ");
			sql.append(" group by t.ano, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.programa_academico ");
			sql.append(" ) as a ");
			sql.append(" inner join (select ma.programa_academico, ");
			sql.append(" sum(matriculas + cancelaciones) as estudiantes ");
			sql.append(" from ( select count(distinct ma.codigo_est) as matriculas, ");
			sql.append(" ma.programa_academico ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" group by ma.programa_academico ");
			sql.append(" ) as ma ");
			sql.append(" left join (select count(ca.codigo_est) as cancelaciones, ");
			sql.append(" ca.programa_academico ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" group by ca.programa_academico ");
			sql.append(" ) as c ");
			sql.append(" on c.programa_academico = ma.programa_academico ");
			sql.append(" group by ma.programa_academico ");
			sql.append(" ) as k ");
			sql.append(" on k.programa_academico = a.programa_academico ");
			sql.append(" inner join academic:acpro001.programas_academic pg ");
			sql.append(" on pg.programa_academico = a.programa_academico ");
			sql.append(" where a.ano = ? and ");
			sql.append(" a.periodo = ? ");
			sql.append(" group by a.programa_academico,pg.nombre_programa ,k.estudiantes ");
			sql.append(" order by pg.nombre_programa ");
			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				HisProgramas co = new HisProgramas();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setEstudiantes(fila.getInt("estudiantes"));
				co.setSegundados(fila.getInt("segundados"));
				co.setEntercerados(fila.getInt("entercerados"));
				co.setEncuartados(fila.getInt("encuartados"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* HISTORICO PROGRAMAS SEDES */
	@WebMethod
	public List<HisProgramasSedes> getHisProgramasSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<HisProgramasSedes> can = new ArrayList<HisProgramasSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT a.programa_academico, ");
			sql.append(" pg.nombre_programa, ");
			sql.append(" a.codigo_sede, ");
			sql.append(" a.estudiantes, ");
			sql.append(" case when k.segundados is null then 0 ");
			sql.append(" else k.segundados ");
			sql.append(" end segundados, ");
			sql.append(" case when k.entercerados is null then 0 ");
			sql.append(" else k.entercerados ");
			sql.append(" end entercerados, ");
			sql.append(" case when k.encuartados is null then 0 ");
			sql.append(" else k.encuartados ");
			sql.append(" end encuartados ");
			sql.append(" from (select j.programa_academico, ");
			sql.append(" count(j.codigo_est) as estudiantes, ");
			sql.append(" j.codigo_sede ");
			sql.append(
					" from (select distinct ma.codigo_est,ma.programa_academico,ma.ano_matric,ma.periodo_matric,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" ) as ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pd.codigo_sede is not null ");
			sql.append(" ) as j ");
			sql.append(" group by j.codigo_sede,j.programa_academico ");
			sql.append(" ) as a ");
			sql.append(" left join (select z.codigo_sede, ");
			sql.append(" z.programa_academico, ");
			sql.append(" count (case when z.perdidas = 1 then 1 end) as segundados, ");
			sql.append(" count (case when z.perdidas = 2 then 1 end) as entercerados, ");
			sql.append(" count(case when z.perdidas = 3 then 1 end) as encuartados ");
			sql.append(" from (  select t.ano, ");
			sql.append(" max(p.periodo_matric) as periodo, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.codigo_sede, ");
			sql.append(" max(t.perdidas) as perdidas, ");
			sql.append(" t.programa_academico ");
			sql.append(" from(select max(n.ano_matric) as ano, ");
			sql.append(" n.codigo_est, ");
			sql.append(" count (n.codigo_asignatura) as perdidas, ");
			sql.append(" n.codigo_sede, ");
			sql.append(" n.programa_academico, ");
			sql.append(" n.codigo_asignatura ");
			sql.append(" from (select distinct dp2.periodo_matric, ");
			sql.append(
					" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura,prog.codigo_sede ");
			sql.append(" FROM ");
			sql.append(" acinsed:insed001.notas_periodo_est dp2 ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" inner join acinsed:insed001.programas_acad_est prog ");
			sql.append(" on prog.programa_academico = dp2.programa_academico and ");
			sql.append(" prog.codigo_est = dp2.codigo_est ");
			sql.append(" WHERE ");
			sql.append(" dp2.nota_n_def_asig between 0.0 and 2.9 or ");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as n ");
			sql.append(" group by n.codigo_est, n.codigo_asignatura,n.codigo_sede,n.programa_academico ");
			sql.append(" ) as t ");
			sql.append(" inner join (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM acinsed:insed001.notas_periodo_est dp2");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE dp2.nota_n_def_asig between 0.0 and 2.9 or");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as p ");
			sql.append(" on p.ano_matric = t.ano and ");
			sql.append(" p.codigo_asignatura = t.codigo_asignatura and ");
			sql.append(" p.codigo_est = t.codigo_est ");
			sql.append(" group by t.ano, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.codigo_sede, ");
			sql.append(" t.programa_academico ");
			sql.append(" ) as z ");
			sql.append(" where z.ano = ? and  ");
			sql.append(" z.periodo = ? ");
			sql.append(" group by z.codigo_sede,z.programa_academico ");
			sql.append(" ) as k ");
			sql.append(" on k.codigo_sede = a.codigo_sede and ");
			sql.append(" k.programa_academico = a.programa_academico ");
			sql.append(" inner join academic:acpro001.programas_academic pg ");
			sql.append(" on pg.programa_academico = a.programa_academico ");
			sql.append(" order by pg.nombre_programa ");
			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				HisProgramasSedes co = new HisProgramasSedes();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setEstudiantes(fila.getInt("estudiantes"));
				co.setSegundados(fila.getInt("segundados"));
				co.setEntercerados(fila.getInt("entercerados"));
				co.setEncuartados(fila.getInt("encuartados"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* HISTORICO ASIGNATURA */
	@WebMethod
	public List<HisAsignaturas> getHisAsignaturas(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<HisAsignaturas> can = new ArrayList<HisAsignaturas>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT a.programa_academico, ");
			sql.append(" prog.nombre_programa as programa, ");
			sql.append(" a.codigo_asignatura, ");
			sql.append(" asig.nombre_asignatura as asignatura,");
			sql.append(" k.estudiantes, ");
			sql.append(" a.segundados, ");
			sql.append(" a.entercerados, ");
			sql.append(" a.encuartados ");
			sql.append(" from (select x.programa_academico, ");
			sql.append("  x.codigo_asignatura, ");
			sql.append(" count(case when x.perdidas = 1 then 1 end) as segundados, ");
			sql.append(" count(case when x.perdidas = 2 then 1 end) as entercerados, ");
			sql.append(" count(case when x.perdidas = 3 then 1 end) as encuartados ");
			sql.append(" from (select t.ano, ");
			sql.append(" max(p.periodo_matric) as periodo, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.perdidas, ");
			sql.append(" t.programa_academico, ");
			sql.append(" t.codigo_asignatura ");
			sql.append(" from(select max(n.ano_matric) as ano, ");
			sql.append(" n.codigo_est, ");
			sql.append(" count (n.codigo_asignatura) as perdidas, ");
			sql.append(" n.programa_academico, ");
			sql.append(" n.codigo_asignatura ");
			sql.append(" from (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM ");
			sql.append(" acinsed:insed001.notas_periodo_est dp2 ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE ");
			sql.append(" dp2.nota_n_def_asig between 0.0 and 2.9 or ");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as n ");
			sql.append(" group by n.codigo_est, n.codigo_asignatura,n.programa_academico ");
			sql.append(" ) as t ");
			sql.append(" inner join (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM acinsed:insed001.notas_periodo_est dp2");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE dp2.nota_n_def_asig between 0.0 and 2.9 or");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as p ");
			sql.append(" on p.ano_matric = t.ano and ");
			sql.append(" p.codigo_asignatura = t.codigo_asignatura and ");
			sql.append(" p.codigo_est = t.codigo_est ");
			sql.append(" group by t.ano, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.perdidas, ");
			sql.append(" t.programa_academico, ");
			sql.append(" t.codigo_asignatura ");
			sql.append(" ) as x ");
			sql.append(" where x.ano = ? and ");
			sql.append(" x.periodo = ? ");
			sql.append(" group by x.programa_academico,x.codigo_asignatura ");
			sql.append(" ) as a ");
			sql.append(" inner join (select j.programa_academico, ");
			sql.append(" j.codigo_asignatura, ");
			sql.append(" sum(j.cancelaciones+ j.homo + j.estu) as estudiantes ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_asignatura, ");
			sql.append(" case when ca.cancelaciones is null then 0 ");
			sql.append(" else ca.cancelaciones ");
			sql.append(" end as cancelaciones, ");
			sql.append(" case when n.homo is null then 0 ");
			sql.append(" else n.homo ");
			sql.append(" end as homo, ");
			sql.append(" count(distinct codigo_est) as estu ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" left join (select c.programa_academico, ");
			sql.append(" c.codigo_asignatura, ");
			sql.append(" count (c.codigo_est) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig c ");
			sql.append(" where c.ano_cancel = ? ");
			sql.append(" and c.periodo_cancel = ? ");
			sql.append(" group by c.programa_academico,c.codigo_asignatura ");
			sql.append(" ) as ca ");
			sql.append(" on ca.programa_academico = ma.programa_academico and ");
			sql.append(" ca.codigo_asignatura = ma.codigo_asignatura ");
			sql.append(" left join (select nt.programa_academico, ");
			sql.append(" nt.codigo_asignatura, ");
			sql.append(" count(nt.codigo_est) as homo ");
			sql.append(" from acinsed:insed001.notas_periodo_est  nt ");
			sql.append(" where nt.grupo = 'HOM' and ");
			sql.append(" nt.ano_matric = ? and ");
			sql.append(" nt.periodo_matric = ? ");
			sql.append(" group by nt.programa_academico, nt.codigo_asignatura ");
			sql.append(" ) as n ");
			sql.append(" on n.programa_academico = ma.programa_academico and ");
			sql.append(" n.codigo_asignatura = ma.codigo_asignatura ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? ");
			sql.append(" group by ma.programa_academico, ");
			sql.append(" ma.codigo_asignatura, ");
			sql.append(" cancelaciones, ");
			sql.append(" homo ");
			sql.append(" ) as j ");
			sql.append(" group by j.programa_academico,j.codigo_asignatura ");
			sql.append(" ) as k ");
			sql.append(" on k.programa_academico = a.programa_academico and ");
			sql.append(" k.codigo_asignatura = a.codigo_asignatura ");
			sql.append(" inner join academic:acpro001.asignaturas asig ");
			sql.append(" on asig.codigo_asignatura = a.codigo_asignatura ");
			sql.append(" inner join academic:acpro001.programas_academic prog ");
			sql.append(" on prog.programa_academico = a.programa_academico ");
			sql.append(" order by a.codigo_asignatura ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				HisAsignaturas co = new HisAsignaturas();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setPrograma(fila.getString("programa"));
				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setAsignatura(fila.getString("asignatura"));
				co.setEstudiantes(fila.getInt("estudiantes"));
				co.setSegundados(fila.getInt("segundados"));
				co.setEntercerados(fila.getInt("entercerados"));
				co.setEncuartados(fila.getInt("encuartados"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* HISTORICO ASIGNATURA */
	@WebMethod
	public List<HisAsignaturasSedes> getHisAsignaturasSedes(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int ann = anio - 3;
		int anio1 = anio + 1;
		List<HisAsignaturasSedes> can = new ArrayList<HisAsignaturasSedes>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT a.programa_academico, ");
			sql.append(" progi.nombre_programa as programa, ");
			sql.append(" a.codigo_asignatura, ");
			sql.append(" asig.nombre_asignatura as asignatura, ");
			sql.append(" a.codigo_sede, ");
			sql.append(" k.estudiantes, ");
			sql.append(" a.segundados, ");
			sql.append(" a.entercerados, ");
			sql.append(" a.encuartados ");
			sql.append(" from (select z.programa_academico, ");
			sql.append(" z.codigo_asignatura, ");
			sql.append(" z.codigo_sede, ");
			sql.append(" count(case when z.perdidas = 1 then 1 end) as segundados, ");
			sql.append(" count(case when z.perdidas = 2 then 1 end) as entercerados, ");
			sql.append(" count(case when z.perdidas = 3 then 1 end) as encuartados ");
			sql.append(" from (select t.ano, ");
			sql.append(" max(p.periodo_matric) as periodo, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.perdidas, ");
			sql.append(" t.codigo_sede, ");
			sql.append(" t.programa_academico, ");
			sql.append(" t.codigo_asignatura ");
			sql.append(" from(select max(n.ano_matric) as ano, ");
			sql.append(" n.codigo_est, ");
			sql.append(" count (n.codigo_asignatura) as perdidas, ");
			sql.append(" n.codigo_sede, ");
			sql.append(" n.programa_academico, ");
			sql.append(" n.codigo_asignatura ");
			sql.append(" from (select distinct dp2.periodo_matric, ");
			sql.append(
					" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura,prog.codigo_sede ");
			sql.append(" FROM ");
			sql.append(" acinsed:insed001.notas_periodo_est dp2 ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" left join acinsed:insed001.programas_acad_est prog ");
			sql.append(" on prog.programa_academico = dp2.programa_academico and ");
			sql.append(" prog.codigo_est = dp2.codigo_est ");
			sql.append(" WHERE ");
			sql.append(" dp2.nota_n_def_asig between 0.0 and 2.9 or ");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as n ");
			sql.append(" group by n.codigo_est, n.codigo_asignatura,n.codigo_sede,n.programa_academico ");
			sql.append(" ) as t ");
			sql.append(" inner join (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM acinsed:insed001.notas_periodo_est dp2");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE dp2.nota_n_def_asig between 0.0 and 2.9 or");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as p ");
			sql.append(" on p.ano_matric = t.ano and ");
			sql.append(" p.codigo_asignatura = t.codigo_asignatura and ");
			sql.append(" p.codigo_est = t.codigo_est ");
			sql.append(" group by t.ano, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.perdidas, ");
			sql.append(" t.codigo_sede, ");
			sql.append(" t.programa_academico, ");
			sql.append(" t.codigo_asignatura ");
			sql.append(" ) as z ");
			sql.append(" where z.ano = ? and ");
			sql.append(" z.periodo = ? ");
			sql.append(" group by z.codigo_sede,z.programa_academico, z.codigo_asignatura ");
			sql.append(" ) as a ");
			sql.append(" left join (select j.programa_academico, ");
			sql.append(" j.codigo_asignatura, ");
			sql.append(" j.codigo_sede, ");
			sql.append(" SUM (j.estudiantes + ");
			sql.append(" j.cancelaciones + ");
			sql.append(" case when n.homo is null then 0 ");
			sql.append(" else n.homo ");
			sql.append(" end) as estudiantes ");
			sql.append(" from (select m.codigo_sede, ");
			sql.append(" m.programa_academico, ");
			sql.append(" m.codigo_asignatura, ");
			sql.append(" m.estudiantes, ");
			sql.append(" case when ca.cancelaciones is null then 0 ");
			sql.append(" else ca.cancelaciones ");
			sql.append(" end as cancelaciones ");
			sql.append(" from (select pro.codigo_sede, ");
			sql.append(" ma.programa_academico, ");
			sql.append(" ma.codigo_asignatura, ");
			sql.append(" count(distinct ma.codigo_est) as estudiantes ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" where pr.ano_condicion between ? and ? ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ma.programa_academico and ");
			sql.append(" pro.codigo_est = ma.codigo_est ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pro.codigo_sede is not null ");
			sql.append(" group by pro.codigo_sede, ");
			sql.append(" ma.programa_academico, ");
			sql.append(" ma.codigo_asignatura ");
			sql.append(" )as m ");
			sql.append(" full outer join (select  pro.codigo_sede, ");
			sql.append(" c.programa_academico, ");
			sql.append(" c.codigo_asignatura, ");
			sql.append(" count (c.codigo_est) as cancelaciones ");
			sql.append(" from acinsed:insed001.cancelaciones_asig c ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" where pr.ano_condicion between ? and ? ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = c.programa_academico and ");
			sql.append(" pro.codigo_est = c.codigo_est ");
			sql.append(" where c.ano_cancel = ? and ");
			sql.append(" c.periodo_cancel = ? and ");
			sql.append(" pro.codigo_sede is not null ");
			sql.append(" group by pro.codigo_sede, ");
			sql.append(" c.programa_academico, ");
			sql.append(" c.codigo_asignatura ");
			sql.append(" ) as ca ");
			sql.append(" on ca.programa_academico = m.programa_academico and ");
			sql.append(" ca.codigo_sede = m.codigo_sede and ");
			sql.append(" ca.codigo_asignatura = m.codigo_asignatura ");
			sql.append(" ) as j ");
			sql.append(" full outer join (select nt.programa_academico, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" nt.codigo_asignatura, ");
			sql.append(" count(nt.codigo_est) as homo ");
			sql.append(" from acinsed:insed001.notas_periodo_est nt ");
			sql.append(" inner join acinsed:insed001.programas_acad_est pro ");
			sql.append(" on pro.programa_academico = nt.programa_academico and ");
			sql.append(" pro.codigo_est = nt.codigo_est ");
			sql.append(" where nt.grupo = 'HOM' and ");
			sql.append(" nt.ano_matric = ? and ");
			sql.append(" nt.periodo_matric = ? ");
			sql.append(" group by pro.codigo_sede,nt.programa_academico, nt.codigo_asignatura ");
			sql.append(" ) as n ");
			sql.append(" on n.programa_academico = j.programa_academico and ");
			sql.append(" n.codigo_sede = j.codigo_sede and ");
			sql.append(" n.codigo_asignatura = j.codigo_asignatura ");
			sql.append(" group by j.codigo_sede,j.programa_academico,j.codigo_asignatura ");
			sql.append(" ) as k ");
			sql.append(" on k.programa_academico = a.programa_academico and ");
			sql.append(" k.codigo_sede = a.codigo_sede and ");
			sql.append(" k.codigo_asignatura = a.codigo_asignatura ");
			sql.append(" inner join academic:acpro001.asignaturas asig ");
			sql.append(" on asig.codigo_asignatura = a.codigo_asignatura ");
			sql.append(" inner join academic:acpro001.programas_academic progi ");
			sql.append(" on progi.programa_academico = a.programa_academico ");
			sql.append(" order by a.codigo_asignatura ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, ann);
			stm.setInt(4, anio1);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, ann);
			stm.setInt(8, anio1);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				HisAsignaturasSedes co = new HisAsignaturasSedes();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setPrograma(fila.getString("programa"));
				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setAsignatura(fila.getString("asignatura"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setEstudiantes(fila.getInt("estudiantes"));
				co.setSegundados(fila.getInt("segundados"));
				co.setEntercerados(fila.getInt("entercerados"));
				co.setEncuartados(fila.getInt("encuartados"));
				can.add(co);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE GENERO SEMESTRE ACTUAL */
	@WebMethod
	public List<EstGenero> getEstGenero(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstGenero> can = new ArrayList<EstGenero>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa, ");
			sql.append(" pa.programa_academico, ");
			sql.append(" dp.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" dp.genero, ");
			sql.append(" con.descripcion, ");
			sql.append(" l.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" dp.direccion_electron ");
			sql.append(" from acinsed:insed001.datos_personal_est dp ");
			sql.append(" inner join acinsed:insed001.programas_acad_est l ");
			sql.append(" on l.codigo_est = dp.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic pa on ");
			sql.append(" pa.programa_academico = l.programa_academico ");
			sql.append(" inner join academic:acpro001.municipios mu on ");
			sql.append(" mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" inner join academic:acpro001.condicionalidades con on ");
			sql.append(" con.condicionalidad = l.condicionalidad ");
			sql.append(" where ");
			sql.append(" ano_condicion = ? ");
			sql.append(" and periodo_condicion = ? ");
			sql.append(" order by ");
			sql.append(" pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			System.out.print(stm);
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				EstGenero co = new EstGenero();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setGenero(fila.getString("genero"));
				co.setDescripcion(fila.getString("descripcion"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE GENERO HISTORIAL */
	@WebMethod
	public List<EstGenero> getEstGeneroHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstGenero> can = new ArrayList<EstGenero>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa, ");
			sql.append(" pa.programa_academico, ");
			sql.append(" dp.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" dp.genero, ");
			sql.append(" con.descripcion, ");
			sql.append(" l.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" dp.direccion_electron ");
			sql.append(
					" from (select distinct dt.codigo_est, m.programa_academico, dt.condicionalidad, pg.codigo_sede ");
			sql.append(" from acinsed:insed001.datos_periodo_est dt ");
			sql.append(" full outer join (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric,");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico,");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est, ");
			sql.append(" pc.ano_condicion, ");
			sql.append(" pc.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" ) as m ");
			sql.append(" on m.codigo_est = dt.codigo_est ");
			sql.append(" and m.programa_academico = dt.programa_academico ");
			sql.append(" and m.ano_matric = dt.ano_academico ");
			sql.append(" and m.periodo_matric = dt.periodo_acad ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = dt.codigo_est ");
			sql.append(" and pg.programa_academico = m.programa_academico ");
			sql.append(" where dt.ano_academico = ? ");
			sql.append(" and dt.periodo_acad = ? ");
			sql.append(" and m.programa_academico is not null ");
			sql.append(" and pg.condicionalidad <> 7 ");
			sql.append(" and pg.condicionalidad <> 3 ");
			sql.append(" union ");
			sql.append(" select pc.codigo_est, pc.programa_academico, pc.condicionalidad, pc.codigo_sede ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (3,5,8,4,12,7,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" ) as li  ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = li.codigo_est ");
			sql.append(" inner join acinsed:insed001.programas_acad_est l ");
			sql.append(" on l.codigo_est = dp.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic pa on ");
			sql.append(" pa.programa_academico = l.programa_academico ");
			sql.append(" inner join academic:acpro001.municipios mu on ");
			sql.append(" mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" inner join academic:acpro001.condicionalidades con on ");
			sql.append(" con.condicionalidad = l.condicionalidad ");
			sql.append(" where ");
			sql.append(" ano_condicion = ? ");
			sql.append(" and periodo_condicion = ? ");
			sql.append(" order by ");
			sql.append(" pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			System.out.print(stm);
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				EstGenero co = new EstGenero();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setGenero(fila.getString("genero"));
				co.setDescripcion(fila.getString("descripcion"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE PRIMER NIVEL */
	@WebMethod
	public List<EstNivel> getEstNivel(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstNivel> can = new ArrayList<EstNivel>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa, ");
			sql.append(" pa.programa_academico, ");
			sql.append(" dp.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" con.descripcion, ");
			sql.append(" l.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" dp.direccion_electron ");
			sql.append(" from acinsed:insed001.datos_personal_est dp ");
			sql.append(" inner join acinsed:insed001.programas_acad_est l ");
			sql.append(" on l.codigo_est = dp.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic pa on ");
			sql.append(" pa.programa_academico = l.programa_academico ");
			sql.append(" inner join academic:acpro001.municipios mu on ");
			sql.append(" mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" inner join academic:acpro001.condicionalidades con on ");
			sql.append(" con.condicionalidad = l.condicionalidad ");
			sql.append(" where l.ano_condicion = ? ");
			sql.append(" and l.periodo_condicion = ? ");
			sql.append(" and l.ano_ing_sede = ? ");
			sql.append(" and l.periodo_ing_sede = ? ");
			sql.append(" and l.forma_ingreso = 2 ");
			sql.append(" order by ");
			sql.append(" pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			System.out.print(stm);
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				EstNivel co = new EstNivel();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setDescripcion(fila.getString("descripcion"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE PRIMER NIVEL HISTORICO */
	@WebMethod
	public List<EstNivel> getEstNivelHis(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstNivel> can = new ArrayList<EstNivel>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa, ");
			sql.append(" pa.programa_academico, ");
			sql.append(" dp.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" con.descripcion, ");
			sql.append(" li.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" dp.direccion_electron ");
			sql.append(
					" from (select distinct dt.codigo_est, m.programa_academico, dt.condicionalidad, pg.ano_ing_sede, pg.periodo_ing_sede, pg.forma_ingreso, pg.codigo_sede ");
			sql.append(" from acinsed:insed001.datos_periodo_est dt ");
			sql.append(" full outer join (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est, ");
			sql.append(" pc.ano_condicion, ");
			sql.append(" pc.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" ) as m ");
			sql.append(" on m.codigo_est = dt.codigo_est ");
			sql.append(" and m.programa_academico = dt.programa_academico ");
			sql.append(" and m.ano_matric = dt.ano_academico ");
			sql.append(" and m.periodo_matric = dt.periodo_acad ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pg ");
			sql.append(" on pg.codigo_est = dt.codigo_est ");
			sql.append(" and pg.programa_academico = m.programa_academico ");
			sql.append(" where dt.ano_academico = ? ");
			sql.append(" and dt.periodo_acad = ? ");
			sql.append(" and m.programa_academico is not null ");
			sql.append(" and pg.condicionalidad <> 7 ");
			sql.append(" and pg.condicionalidad <> 3 ");
			sql.append(" union ");
			sql.append(
					" select pc.codigo_est, pc.programa_academico, pc.condicionalidad, pc.ano_ing_sede, pc.periodo_ing_sede, pc.forma_ingreso, pc.codigo_sede ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (3,5,8,4,12,7,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" ) as li ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = li.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic pa on ");
			sql.append(" pa.programa_academico = li.programa_academico ");
			sql.append(" inner join academic:acpro001.municipios mu on ");
			sql.append(" mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" inner join academic:acpro001.condicionalidades con on ");
			sql.append(" con.condicionalidad = li.condicionalidad ");
			sql.append(" where li.ano_ing_sede = ? ");
			sql.append(" and li.periodo_ing_sede = ? ");
			sql.append(" and li.forma_ingreso = 2 ");
			sql.append(" order by ");
			sql.append(" pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			System.out.print(stm);
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			stm.setInt(11, anio);
			stm.setInt(12, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				EstNivel co = new EstNivel();
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setNombre(fila.getString("nombre_programa"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setDescripcion(fila.getString("descripcion"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE APROBADOS */
	@WebMethod
	public List<EstAprobacion> getEstAprobacion(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstAprobacion> can = new ArrayList<EstAprobacion>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT po.nombre_programa as programa, ");
			sql.append(" a.nombre_asignatura as asignatura, ");
			sql.append(" po.programa_academico, ");
			sql.append(" a.codigo_asignatura, ");
			sql.append(" dp.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" case ");
			sql.append(" when np.nota_n_def_asig between 3.0 and 5.0 then np.nota_n_def_asig::char(7) ");
			sql.append(" when np.nota_c_def_asig = 'A' then np.nota_c_def_asig ");
			sql.append(" when np.nota_n_def_asig between 0.0 and 2.9 then np.nota_n_def_asig::char(7) ");
			sql.append(" when np.nota_c_def_asig = 'R' then np.nota_c_def_asig ");
			sql.append(" end as notas, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" dp.direccion_electron ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join acinsed:insed001.programas_acad_est as pro ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est and ");
			sql.append(" pro.ano_condicion = np.ano_matric and ");
			sql.append(" pro.periodo_condicion = np.periodo_matric ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = np.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic po on ");
			sql.append(" po.programa_academico = np.programa_academico ");
			sql.append(" inner join academic:acpro001.municipios mu on ");
			sql.append(" mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" inner join academic:acpro001.asignaturas a  ");
			sql.append(" on a.codigo_asignatura = np.codigo_asignatura ");
			sql.append(" where np.ano_matric = ? ");
			sql.append(" and np.periodo_matric = ? ");
			sql.append(" order by ");
			sql.append(" po.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			System.out.print(stm);
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				EstAprobacion co = new EstAprobacion();
				co.setPrograma(fila.getString("programa"));
				co.setAsignatura(fila.getString("asignatura"));
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setNotas(fila.getString("notas"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE APROBADOS HISTORICO */
	@WebMethod
	public List<EstAprobacion> getEstAprobacionHist(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstAprobacion> can = new ArrayList<EstAprobacion>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT po.nombre_programa as programa, ");
			sql.append(" a.nombre_asignatura as asignatura, ");
			sql.append(" po.programa_academico, ");
			sql.append(" a.codigo_asignatura, ");
			sql.append(" dp.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" case ");
			sql.append(" when np.nota_n_def_asig between 3.0 and 5.0 then np.nota_n_def_asig::char(7) ");
			sql.append(" when np.nota_c_def_asig = 'A' then np.nota_c_def_asig ");
			sql.append(" when np.nota_n_def_asig between 0.0 and 2.9 then np.nota_n_def_asig::char(7) ");
			sql.append(" when np.nota_c_def_asig = 'R' then np.nota_c_def_asig ");
			sql.append(" end as notas, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" dp.direccion_electron ");
			sql.append(" from acinsed:insed001.notas_periodo_est np ");
			sql.append(" inner join (select ");
			sql.append(" distinct pd.codigo_est, ");
			sql.append(" pd.programa_academico, ");
			sql.append(" pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est ");
			sql.append(" from ");
			sql.append(" acinsed:insed001.matriculas ma ");
			sql.append(" where ");
			sql.append(" ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ");
			sql.append(" ca.programa_academico, ");
			sql.append(" ca.codigo_est ");
			sql.append(" from ");
			sql.append(" acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ");
			sql.append(" ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" ) as ma ");
			sql.append(" left join acinsed:insed001.programas_acad_est pd on ");
			sql.append(" pd.codigo_est = ma.codigo_est ");
			sql.append(" and pd.programa_academico = ma.programa_academico ");
			sql.append(" where ");
			sql.append(" pd.codigo_est is not null ");
			sql.append(" )as pro  ");
			sql.append(" on pro.programa_academico = np.programa_academico and ");
			sql.append(" pro.codigo_est = np.codigo_est ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = np.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic po on ");
			sql.append(" po.programa_academico = np.programa_academico ");
			sql.append(" inner join academic:acpro001.municipios mu on ");
			sql.append(" mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" inner join academic:acpro001.asignaturas a  ");
			sql.append(" on a.codigo_asignatura = np.codigo_asignatura ");
			sql.append(" where np.ano_matric = ? ");
			sql.append(" and np.periodo_matric = ? ");
			sql.append(" order by ");
			sql.append(" po.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				EstAprobacion co = new EstAprobacion();
				co.setPrograma(fila.getString("programa"));
				co.setAsignatura(fila.getString("asignatura"));
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setNotas(fila.getString("notas"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE ACADEMICO */
	@WebMethod
	public List<EstAcademico> getEstAcademico(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstAcademico> can = new ArrayList<EstAcademico>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pr.nombre_programa, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" pro.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" dt.prome_pond_acum, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" case when dp.direccion_electron is null then '-' ");
			sql.append(" else dp.direccion_electron ");
			sql.append(" end as direccion_electron ");
			sql.append(" from acinsed:insed001.programas_acad_est pro ");
			sql.append(" inner join acinsed:insed001.datos_periodo_est dt ");
			sql.append(" on dt.programa_academico = pro.programa_academico and ");
			sql.append(" dt.codigo_est = pro.codigo_est and ");
			sql.append(" dt.ano_academico = pro.ano_condicion and ");
			sql.append(" dt.periodo_acad = pro.periodo_condicion ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = pro.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic pr on ");
			sql.append(" pr.programa_academico = pro.programa_academico ");
			sql.append(" inner join academic:acpro001.municipios mu on ");
			sql.append(" mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" where pro.ano_condicion = ? ");
			sql.append(" and pro.periodo_condicion = ? ");
			sql.append(" order by nombres");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				EstAcademico co = new EstAcademico();
				co.setNombre(fila.getString("nombre_programa"));
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setProme_ponde_acum(fila.getDouble("prome_pond_acum"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE ACADEMICO HISTORICO */
	@WebMethod
	public List<EstAcademico> getEstAcademicoHist(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstAcademico> can = new ArrayList<EstAcademico>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pr.nombre_programa, ");
			sql.append(" pr.programa_academico, ");
			sql.append(" p.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" p.prome_pond_acum, ");
			sql.append(" p.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" case when dp.direccion_electron is null then '-' ");
			sql.append(" else dp.direccion_electron ");
			sql.append(" end as direccion_electron ");
			sql.append(" from (select pro.programa_academico, ");
			sql.append(" pro.codigo_est, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" dt.prome_pond_acum ");
			sql.append(
					" from (select distinct ma.codigo_est ,ma.programa_academico,ma.ano_matric,ma.periodo_matric,pd.codigo_sede ");
			sql.append(" from (select distinct ma.programa_academico, ");
			sql.append(" ma.codigo_est, ");
			sql.append(" ma.ano_matric, ");
			sql.append(" ma.periodo_matric ");
			sql.append(" from acinsed:insed001.matriculas ma ");
			sql.append(" where ma.ano_matric = ? ");
			sql.append(" and ma.periodo_matric = ? ");
			sql.append(" union ");
			sql.append(" select ca.programa_academico, ");
			sql.append(" ca.codigo_est, ");
			sql.append(" ca.ano_cancel, ");
			sql.append(" ca.periodo_cancel ");
			sql.append(" from acinsed:insed001.cancelaciones_peri ca ");
			sql.append(" where ca.ano_cancel = ? ");
			sql.append(" and ca.periodo_cancel = ? ");
			sql.append(" union ");
			sql.append(" select pc.programa_academico, ");
			sql.append(" pc.codigo_est, ");
			sql.append(" pc.ano_condicion, ");
			sql.append(" pc.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pc ");
			sql.append(" where pc.condicionalidad in (5,8,4,7,3,12,13,14,15,16,17,9,10,6,18) and ");
			sql.append(" pc.ano_condicion = ? and ");
			sql.append(" pc.periodo_condicion = ? and ");
			sql.append(" pc.condicionalidad is not null ");
			sql.append(" ) as ma ");
			sql.append(" full outer join acinsed:insed001.programas_acad_est pd ");
			sql.append(" on pd.codigo_est = ma.codigo_est and ");
			sql.append(" pd.programa_academico = ma.programa_academico ");
			sql.append(" where ma.ano_matric = ? and ");
			sql.append(" ma.periodo_matric = ? and ");
			sql.append(" pd.codigo_sede is not null ");
			sql.append(" ) AS pro ");
			sql.append(" left join acinsed:insed001.datos_periodo_est dt ");
			sql.append(" on dt.programa_academico = pro.programa_academico and ");
			sql.append(" dt.codigo_est = pro.codigo_est and ");
			sql.append(" dt.ano_academico = pro.ano_matric and ");
			sql.append(" dt.periodo_acad = pro.periodo_matric ");
			sql.append(" where pro.ano_matric = ? and ");
			sql.append(" pro.periodo_matric = ? ");
			sql.append(" ) as p ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = p.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic pr on ");
			sql.append(" pr.programa_academico = p.programa_academico ");
			sql.append(" inner join academic:acpro001.municipios mu on ");
			sql.append(" mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" where p.prome_pond_acum is not null ");
			sql.append(" order by ");
			sql.append(" nombres ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			stm.setInt(5, anio);
			stm.setInt(6, periodo);
			stm.setInt(7, anio);
			stm.setInt(8, periodo);
			stm.setInt(9, anio);
			stm.setInt(10, periodo);
			fila = stm.executeQuery();
			while (fila.next()) {
				EstAcademico co = new EstAcademico();
				co.setNombre(fila.getString("nombre_programa"));
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setProme_ponde_acum(fila.getDouble("prome_pond_acum"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE CANCELACIONES */
	@WebMethod
	public List<EstCancelaciones> getEstCancelaciones(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		int anio1 = anio + 1;
		List<EstCancelaciones> can = new ArrayList<EstCancelaciones>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa as programa, ");
			sql.append(" a.nombre_asignatura as asignatura, ");
			sql.append(" pa.programa_academico, ");
			sql.append(" a.codigo_asignatura, ");
			sql.append(" ca.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" pro.codigo_sede, ");
			sql.append(" cu.descripcion_causa, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" case when dp.direccion_electron is null then '-' ");
			sql.append(" else dp.direccion_electron ");
			sql.append(" end as direccion_electron ");
			sql.append(" from acinsed:insed001.cancelaciones_asig ca ");
			sql.append(
					" left join (select distinct pr.programa_academico, pr.codigo_sede, pr.codigo_est, pr.periodo_condicion ");
			sql.append(" from acinsed:insed001.programas_acad_est pr ");
			sql.append(" where pr.ano_condicion between ? and ? ");
			sql.append(" ) as pro ");
			sql.append(" on pro.programa_academico = ca.programa_academico ");
			sql.append(" and pro.codigo_est = ca.codigo_est ");
			sql.append(" inner join academic:acpro001.programas_academic pa ");
			sql.append(" on pa.programa_academico = ca.programa_academico ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = ca.codigo_est ");
			sql.append(" inner join academic:acpro001.municipios mu ");
			sql.append(" on mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" inner join academic:acpro001.asignaturas a ");
			sql.append(" on a.codigo_asignatura  = ca.codigo_asignatura ");
			sql.append(" inner join academic:acpro001.causas_cancel_asig cu ");
			sql.append(" on cu.causa_cancel_asig = ca.causa_cancel_asig ");
			sql.append(" where ca.ano_cancel = ? and ");
			sql.append(" ca.periodo_cancel = ? ");
			sql.append(" order by pa.nombre_programa ");

			stm = conexion.prepareStatement(sql.toString());
			stm.setInt(1, anio);
			stm.setInt(2, anio1);
			stm.setInt(3, anio);
			stm.setInt(4, periodo);
			fila = stm.executeQuery();

			while (fila.next()) {
				EstCancelaciones co = new EstCancelaciones();
				co.setPrograma(fila.getString("programa"));
				co.setAsignatura(fila.getString("asignatura"));
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDescripcion_causa(fila.getString("descripcion_causa"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

	/* LISTADO DE ESTUDIANTES DE HISTORIAL DE PERDIDAS */
	@WebMethod
	public List<EstHistorial> getEstHistorial(int anio, int periodo) {

		this.conectar();
		PreparedStatement stm = null;
		ResultSet fila = null;
		List<EstHistorial> can = new ArrayList<EstHistorial>();

		try {
			StringBuilder sql = new StringBuilder();
			sql.append(" SELECT pa.nombre_programa as programa, ");
			sql.append(" a.nombre_asignatura as asignatura, ");
			sql.append(" pa.programa_academico, ");
			sql.append(" a.codigo_asignatura, ");
			sql.append(" z.codigo_est, ");
			sql.append(
					" case when dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido is null then '-' ");
			sql.append(
					" else dp.primer_nombre ||''||dp.segundo_nombre ||''||dp.primer_nombre ||''||dp.segundo_apellido ");
			sql.append(" end as nombres, ");
			sql.append(" case ");
			sql.append(" when z.perdidas = 1 then 'PERDI� 1 VEZ ' ");
			sql.append(" when z.perdidas = 2 then 'PERDI� 2 VECES ' ");
			sql.append(" when z.perdidas = 3 then 'PERDI� 3 VECES ' ");
			sql.append(" end as estado, ");
			sql.append(" z.codigo_sede, ");
			sql.append(" dp.direccion_reside, ");
			sql.append(" mu.nombre_municipio, ");
			sql.append(" dp.telefono_reside, ");
			sql.append(" case when dp.direccion_electron is null then '-' ");
			sql.append(" else dp.direccion_electron ");
			sql.append(" end as direccion_electron ");
			sql.append(" from (select t.ano, ");
			sql.append(" max(p.periodo_matric) as periodo, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.perdidas, ");
			sql.append(" t.codigo_sede, ");
			sql.append(" t.programa_academico, ");
			sql.append(" t.codigo_asignatura ");
			sql.append(" from(select max(n.ano_matric) as ano, ");
			sql.append(" n.codigo_est, ");
			sql.append(" count (n.codigo_asignatura) as perdidas, ");
			sql.append(" n.codigo_sede, ");
			sql.append(" n.programa_academico, ");
			sql.append(" n.codigo_asignatura ");
			sql.append(" from (select distinct dp2.periodo_matric, ");
			sql.append(
					" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura,prog.codigo_sede ");
			sql.append(" FROM ");
			sql.append(" acinsed:insed001.notas_periodo_est dp2 ");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" left join acinsed:insed001.programas_acad_est prog ");
			sql.append(" on prog.programa_academico = dp2.programa_academico and ");
			sql.append(" prog.codigo_est = dp2.codigo_est ");
			sql.append(" WHERE ");
			sql.append(" dp2.nota_n_def_asig between 0.0 and 2.9 or ");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as n ");
			sql.append(" group by n.codigo_est, n.codigo_asignatura,n.codigo_sede,n.programa_academico ");
			sql.append(" ) as t ");
			sql.append(" inner join (select distinct dp2.periodo_matric, ");
			sql.append(" dp2.ano_matric, dp2.codigo_est, dp2.programa_academico, dp2.codigo_asignatura ");
			sql.append(" FROM acinsed:insed001.notas_periodo_est dp2");
			sql.append(" inner join (select pro.programa_academico, ");
			sql.append(" pro.plan_estudio, ");
			sql.append(
					" case when pro.nivel_plan between 1 and 4 and pro.programa_academico = 87 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan between 5 and 6 and pro.programa_academico = 8 then pro.codigo_asignatura ");
			sql.append(
					" when pro.nivel_plan in (7,8,9,10) and pro.programa_academico = 86 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 70 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 71 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 13 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 82 then pro.codigo_asignatura ");
			sql.append(" when pro.programa_academico = 61 then pro.codigo_asignatura ");
			sql.append(" end  as asignaturas ");
			sql.append(" from academic:acpro001.asignaturas_plan pro ");
			sql.append(" union ");
			sql.append(" select asi.programa_academico, ");
			sql.append(" asi.plan_estudio, ");
			sql.append(" asi.codigo_asignatura as asignaturas ");
			sql.append(" from academic:acpro001.asig_electivas_pl asi ");
			sql.append(" where asi.programa_academico in (87,8,86,70,71,13,82,61) ");
			sql.append(" ) as p");
			sql.append(" on p.programa_academico = dp2.programa_academico and ");
			sql.append(" p.asignaturas = dp2.codigo_asignatura ");
			sql.append(" WHERE dp2.nota_n_def_asig between 0.0 and 2.9 or");
			sql.append(" dp2.nota_c_def_asig = 'R' ");
			sql.append(" ) as p ");
			sql.append(" on p.ano_matric = t.ano and ");
			sql.append(" p.codigo_asignatura = t.codigo_asignatura and ");
			sql.append(" p.codigo_est = t.codigo_est ");
			sql.append(" group by t.ano, ");
			sql.append(" t.codigo_est, ");
			sql.append(" t.perdidas, ");
			sql.append(" t.codigo_sede, ");
			sql.append(" t.programa_academico, ");
			sql.append(" t.codigo_asignatura ");
			sql.append(" ) as z ");
			sql.append(" inner join acinsed:insed001.datos_personal_est dp ");
			sql.append(" on dp.codigo_est = z.codigo_est ");
			sql.append(" inner join academic:acpro001.municipios mu ");
			sql.append(" on mu.codigo_municipio = dp.codigo_mun_res ");
			sql.append(" inner join academic:acpro001.programas_academic pa ");
			sql.append(" on z.programa_academico = pa.programa_academico ");
			sql.append(" inner join academic:acpro001.asignaturas a ");
			sql.append(" on a.codigo_asignatura  = z.codigo_asignatura ");
			sql.append(" where z.ano = ? and ");
			sql.append(" z.periodo = ? ");
			sql.append(" order by nombres ");

			stm = conexion.prepareStatement(sql.toString());

			stm.setInt(1, anio);
			stm.setInt(2, periodo);
			fila = stm.executeQuery();

			while (fila.next()) {
				EstHistorial co = new EstHistorial();
				co.setPrograma(fila.getString("programa"));
				co.setAsignatura(fila.getString("asignatura"));
				co.setPrograma_academico(fila.getInt("programa_academico"));
				co.setCodigo_asignatura(fila.getInt("codigo_asignatura"));
				co.setCodigo_est(fila.getInt("codigo_est"));
				co.setNombres(fila.getString("nombres"));
				co.setEstado(fila.getString("estado"));
				co.setCodigo_sede(fila.getInt("codigo_sede"));
				co.setDireccion_reside(fila.getString("direccion_reside"));
				co.setNombre_municipio(fila.getString("nombre_municipio"));
				co.setTelefono_reside(fila.getString("telefono_reside"));
				co.setDireccion_electron(fila.getString("direccion_electron"));
				can.add(co);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				conexion.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return can;
	}

}
